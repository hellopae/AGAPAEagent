# AGAPAE Widget

การ์ดลอย always-on-top บน macOS แสดง **Claude limits** (session 5 ชม. + weekly) และ
**สถานะทีม AGAPAE** จาก dashboard — สร้างด้วย Tauri v2 + React (Vite)

## ต้องมีในเครื่อง

- Node.js + npm
- Rust toolchain (`rustup` — https://rustup.rs)
- Xcode Command Line Tools
- ล็อกอิน Claude Code แล้ว (token อยู่ใน macOS Keychain item `Claude Code-credentials`)

## Dev

```bash
npm install
npm run tauri dev
```

## Build (.app)

```bash
npm run tauri build
# ได้ไฟล์ที่ src-tauri/target/release/bundle/macos/AGAPAE Widget.app
# ลากไป /Applications ได้เลย (ยังไม่ได้ sign/notarize — เปิดครั้งแรกอาจต้อง right-click > Open)
```

## การใช้งาน

- **แถบบนสุดสลับได้ 4 หน้า** (ลำดับตามที่ Kittanate สั่งเมื่อ 10 ส.ค. 2569 · ผังออฟฟิศรวมอยู่ในแท็บ TEAM AGAPAE ตั้งแต่ 25 ส.ค. 2569)
  ที่ว่างข้าง ๆ ปุ่มยังลากย้ายหน้าต่างได้เหมือนเดิม

  | แท็บ | มีอะไร |
  |---|---|
  | `AGAPAE WIDGET` | Claude limits · Bitcoin · Monthly · ข่าวเช้า · มังงะ · ดูดวง · อีเมล · To Do |
  | `TEAM AGAPAE` | **การ์ดทีม 13 คน** (รูป · สถานะ · งานล่าสุด) → **ผังออฟฟิศ 2D** ที่ทุกคนเดินทำงานตามสถานะจริง → **Work Log** 25 รายการล่าสุดเต็มความกว้างด้านล่าง (กดแถวเพื่อกางสรุปเต็ม) |
  | `การเงิน` | **บน** สรุปเดือนนี้ (รายรับรวม · รายจ่ายรวม · คงเหลือ · กำไร/ขาดทุนสุทธิ) · **ล่าง** ปฏิทินรายรับรายจ่ายเต็มความกว้าง |
  | `VOCABULARY` | 5 คำวันนี้ · เกมทายคำ · ค้นหาคำศัพท์ |

- **ระบบระดับ (เพิ่ม 25 ส.ค. 2569)** — การ์ดทีมทุกใบมีป้าย `LV` + ระดับ และมีแถบ 👑 MVP เหนือแถวการ์ด
  - EXP ต่อหนึ่งงานใน worklog: ส่งออก 12 · เสร็จ 10 · รอแก้ไข 4 · ค้าง 2
  - เลเวลถัดไปใช้ `20 + LV×5` EXP
  - ระดับ: 🌱 Simple (LV1) · 🥈 Silver (5) · 🥇 Gold (10) · 🏆 Platinum (15) · 💎 Diamond (20)
  - 👑 = ปิดงานมากที่สุดใน 7 วันล่าสุด (เสมอกันได้หลายคน) · 🔥 = ทำงานติดกัน 3 วันขึ้นไป
  - สีระดับแยกค่าธีมมืด/สว่างไว้ที่ `--t-simple … --t-diamond` ใน `Office.css`

  > แต่ละแท็บ mount ครั้งแรกที่เปิดแล้วซ่อนไว้ ไม่ unmount — ไม่งั้นพาเนลที่พับไว้
  > วันที่เลือกบนปฏิทิน และคลังคำที่โหลดมาแล้วจะรีเซ็ตทุกครั้งที่สลับแท็บ
- การ์ด frameless always-on-top ลากย้ายได้ (จับที่แถบหัวการ์ด) จำตำแหน่งอัตโนมัติ
- ปุ่ม `–` ย่อ, `✕` ซ่อนการ์ด — เปิดคืน/ออกจากแอปได้จากไอคอนบน menu bar (tray)
- ข้อมูลอัปเดตทุก 5 นาที + แสดงเวลาอัปเดตล่าสุด

## แหล่งข้อมูล

| ส่วน | แหล่ง | หมายเหตุ |
|---|---|---|
| Claude limits | `GET https://api.anthropic.com/api/oauth/usage` (token จาก Keychain, อ่านฝั่ง Rust เท่านั้น) | **ไม่ใช่ API official** — schema อาจเปลี่ยนได้ทุกเมื่อ |
| ทีม AGAPAE | `status.json` + `worklog.json` จาก https://hellopae.github.io/AGAPAEagent/ | CDN cache ~10 นาที — การ์ดแสดง timestamp ของข้อมูลกำกับไว้ |
| Bitcoin | CoinGecko simple price (USD/THB + 24h change) | refresh ทุก 3 นาที ตาม widget บน dashboard |
| ข่าวเช้า | Firestore REST `agents/daily` (project `agapae-studio`) | Daily News routine เขียนทุก 09:00 — ถ้ายังไม่มี doc จะ fallback เป็น entry ล่าสุดของ News agent จาก worklog |
| อีเมลใหม่ | Firestore REST `agents/email` (project `agapae-studio`) | Email Check routine เขียนทุกวัน 08:00 — **แสดงแค่ชื่อผู้ส่ง + เวลา ห้ามมีชื่อเรื่องอีเมล** เพราะ doc นี้อ่านได้ด้วย API key ที่ฝังในหน้าเว็บสาธารณะ |
| Work Log | `worklog.json` จาก https://hellopae.github.io/AGAPAEagent/ | โหลดพร้อม `status.json` ในรอบเดียวกัน (ทุก 5 นาที) · entries ใหม่อยู่บนสุดในไฟล์อยู่แล้ว ไม่ต้อง sort ซ้ำ |
| การเงิน (ตัวเลขสรุป) | Firestore REST `agents/finance` — ฟิลด์ `income` / `expense` / `balance` / `net` | budget2569 เขียนให้ · `net` ติดลบ = ขาดทุน ป้ายบนการ์ดสลับเป็น "กำไร" เองเมื่อเป็นบวก |
| Vocabulary | `vocab.json` จาก https://hellopae.github.io/AGAPAEagent/ + Firestore `agents/vocab` | โหลดครั้งเดียวตอนเปิดแอป · doc `agents/vocab` เก็บ `custom` (คำที่เพิ่มเองจากหน้าเว็บ) และ `known` (คำที่กด "จำได้แล้ว") |
| ระดับ (EXP/LV) | คำนวณในเครื่องจาก `worklog.json` ก้อนเดียวกับ Work Log — `src/levels.js` | ไม่มีตัวเลขปั้น · **สูตรต้องตรงกับหัวข้อ LEVEL ใน `AGAPAE Agent/index.html`** แก้ที่ไหนต้องแก้อีกที่ ไม่งั้นเลเวลบนเว็บกับบน widget จะไม่ตรงกัน |
| Office | รูปใน `public/office/` — bundle มากับแอป | พื้นออฟฟิศ + ตัวละคร SD 13 ตัว ~1.8MB · ไม่ต้องต่อเน็ต · สถานะ/งานของแต่ละคนใช้ `status.json` ก้อนเดียวกับแท็บ TEAM AGAPAE · ถ้าอัปเดตรูปใน repo AGAPAE Agent ต้องคัดลอกมาที่ `public/office/` แล้ว build ใหม่ |

## หน้า Vocabulary

ตั้งใจให้เป็นแค่จุดสะกิดวันละนิด **ไม่ยกคลัง 619 คำมาทั้งก้อน** — คลังเต็ม ตัวกรองหมวด
และฟอร์มเพิ่มคำอยู่บนเว็บ `vocab.html` (มีปุ่มเปิดจากในแอป)

| พาเนล | ทำอะไร |
|---|---|
| 5 คำวันนี้ | flashcard คลิกเปิดความหมาย + ตัวอย่างประโยค · ปุ่ม "จำได้แล้ว" · ปุ่มสุ่มชุดใหม่ |
| เกมทายคำ | 5 ข้อ เห็นคำแปลไทย เลือกคำอังกฤษที่ถูก (ตัวเลือกลวงดึงจากหมวดเดียวกัน) |
| ค้นหาคำศัพท์ | ค้นได้ทั้งไทย/อังกฤษ แสดง 6 อันดับแรก + ปุ่มเปิดคลังเต็มบนเว็บ |

> ⚠️ **การสุ่ม "5 คำวันนี้" ต้องเหมือนกับหน้าเว็บเป๊ะ ๆ** — ทั้งสองฝั่งใช้ LCG seed จาก
> `YYYYMMDD` ตัวเดียวกัน แล้วกรองคำที่อยู่ใน `known` ออกก่อนสุ่ม ถ้าแก้สูตรฝั่งใดฝั่งหนึ่ง
> ต้องแก้อีกฝั่งด้วย (`src/Vocab.jsx` ↔ `AGAPAE Agent/vocab.html`) ไม่งั้นคำจะไม่ตรงกัน

## ข้อจำกัด / ความปลอดภัย

- usage endpoint เป็น internal endpoint ของ Claude Code — ถ้า Anthropic เปลี่ยน schema
  การ์ดจะขึ้น error ฝั่ง limits (ส่วนทีมยังทำงานปกติ) ต้องแก้ `src-tauri/src/lib.rs`
- ห้าม poll ต่ำกว่า 180 วินาที (เสี่ยงโดน 429) — ตอนนี้ตั้งไว้ 5 นาที
- token ไม่ถูก log / ไม่เขียนลงไฟล์ / ไม่ผ่านเข้า frontend — อยู่ในหน่วยความจำฝั่ง Rust เท่านั้น
  frontend ได้เฉพาะ % ที่ประมวลแล้ว
- ครั้งแรกที่รัน macOS อาจถามสิทธิ์อ่าน Keychain — กด Allow

## โครงสร้าง

- `src/` — React frontend (การ์ด UI ภาษาไทย โทนจาก dashboard เดิม)
- `src-tauri/` — Rust: อ่าน Keychain, เรียก usage endpoint, tray icon, window state
- `minnie-idea-cards.md`, `reese-research-brief.md` — เอกสาร idea/research ต้นทางของโปรเจกต์

## ยกเลิกแล้ว

- **แถบ "ประชุมทีม"** — ถอดออก 8 ส.ค. 2569 ตามคำสั่ง Kittanate (ยกเลิกโหมดให้ agent ถกเถียงกัน
  ทั้งชุด ทั้งบน Widget และ dashboard) กลับไปใช้แบบเดิม: Claudy มอบหมายงานแล้วสรุปผล
  ซึ่งดูได้จากแถบ **ทีม AGAPAE** และ Work Log บน dashboard
