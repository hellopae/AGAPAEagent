/* พาเนลพับได้ — ใช้ร่วมกันทั้งหน้า AGAPAE Widget และหน้า Vocabulary */
export default function Panel({ title, right, defaultOpen = false, children }) {
  return (
    <details className="acc" open={defaultOpen}>
      <summary className="acc-bar">
        <span className="acc-title mono">{title}</span>
        {right != null && right !== "" && <span className="acc-right mono">{right}</span>}
      </summary>
      <div className="acc-body">{children}</div>
    </details>
  );
}
