/* หน้า Vocabulary บน widget — ย่อจากหน้าเต็ม https://hellopae.github.io/AGAPAEagent/vocab.html
   ตั้งใจให้ "เหลือบเห็นวันละนิด" ไม่ใช่ยกคลัง 619 คำมาทั้งก้อน:
     · 5 คำวันนี้ (flashcard) — ใช้ seed ตามวันที่แบบเดียวกับหน้าเว็บ คำจึงตรงกันเสมอ
     · เกมทายคำ 5 ข้อ
     · ค้นหาแบบเร็ว + ปุ่มเปิดคลังเต็มบนเว็บ
   คำที่มาร์กว่า "จำได้แล้ว" ซิงก์ผ่าน Firestore agents/vocab (field known) ให้ widget กับเว็บ
   เห็นความคืบหน้าชุดเดียวกัน — ไม่งั้นสองฝั่งจะสุ่มคำคนละชุดเพราะกรอง known ต่างกัน */
import { useCallback, useEffect, useMemo, useState } from "react";
import { openUrl } from "@tauri-apps/plugin-opener";
import Panel from "./Panel";

const PAGES_BASE = "https://hellopae.github.io/AGAPAEagent";
const VOCAB_JSON = `${PAGES_BASE}/vocab.json`;
const VOCAB_PAGE = `${PAGES_BASE}/vocab.html`;
const FS_VOCAB_URL =
  "https://firestore.googleapis.com/v1/projects/agapae-studio/databases/(default)/documents/agents/vocab?key=AIzaSyCtIZVYmibm4Rwb878iEdnxHjvpVcLfs2E";

const CATS = {
  emo: "อารมณ์ ความรู้สึก",
  ppl: "คน นิสัย บุคลิก",
  act: "กริยา การกระทำ",
  des: "คำบรรยาย คุณศัพท์",
  soc: "สังคม การเมือง กฎหมาย",
  rel: "ศาสนา ความเชื่อ พิธีกรรม",
  fan: "แฟนตาซี สงคราม ยุคกลาง",
  day: "ของใช้ อาหาร ชีวิตประจำวัน",
  lng: "ภาษา สื่อ วรรณกรรม",
  phr: "Phrasal verbs",
  sla: "สแลง สำนวน",
  sen: "ประโยคใช้จริง",
  gra: "ไวยากรณ์ คำที่สับสน",
};

const todayKey = () => new Date().toLocaleDateString("sv-SE"); // YYYY-MM-DD ตามเวลาเครื่อง

/* LCG — ผลเหมือนเดิมทุกครั้งในวันเดียวกัน (สูตรเดียวกับ vocab.html) */
function seedRandom(seed) {
  let s = seed % 2147483647;
  if (s <= 0) s += 2147483646;
  return () => (s = (s * 16807) % 2147483647) / 2147483647;
}
function shuffle(a, rnd = Math.random) {
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(rnd() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

/* ── Firestore REST: agents/vocab เก็บ custom (คำที่เพิ่มเอง) + known (คำที่จำได้แล้ว) ── */
function fsWordsFromCustom(f) {
  const arr = f?.custom?.arrayValue?.values ?? [];
  return arr
    .map((v) => {
      const m = v.mapValue?.fields ?? {};
      const s = (k) => m[k]?.stringValue ?? "";
      return { w: s("w"), t: s("t"), c: s("c") || "day", e: s("e"), x: s("x"), n: s("n"), mine: true };
    })
    .filter((w) => w.w && w.t);
}
function fsKnown(f) {
  return (f?.known?.arrayValue?.values ?? []).map((v) => v.stringValue).filter(Boolean);
}
async function pushKnown(list) {
  await fetch(`${FS_VOCAB_URL}&updateMask.fieldPaths=known`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      fields: { known: { arrayValue: { values: list.map((w) => ({ stringValue: w })) } } },
    }),
  }).catch(() => {});
}

/* ── flashcard ── */
function Flash({ word, known, onKnown }) {
  const [open, setOpen] = useState(false);
  return (
    <div className={`vc ${open ? "open" : ""} ${known ? "known" : ""}`} onClick={() => setOpen(!open)}>
      <div className="vc-top">
        <span className="vc-w">{word.w}</span>
        <span className="vc-cat mono">{CATS[word.c] ?? word.c}</span>
      </div>
      {!open && <div className="vc-hint">คลิกเพื่อดูความหมาย</div>}
      {open && (
        <div className="vc-body">
          <div className="vc-t">{word.t}</div>
          {word.e && (
            <div className="vc-ex">
              <div className="vc-en">{word.e}</div>
              {word.x && <div>{word.x}</div>}
            </div>
          )}
          {word.n && <div className="vc-note">{word.n}</div>}
          <button
            className="vc-btn"
            onClick={(e) => {
              e.stopPropagation();
              onKnown(word.w);
            }}
          >
            {known ? "✓ จำได้แล้ว" : "จำได้แล้ว"}
          </button>
        </div>
      )}
    </div>
  );
}

/* ── เกมทายคำ ── */
function Quiz({ pool }) {
  const [round, setRound] = useState(null); // { qs, i, score, picked }

  const start = useCallback(() => {
    if (pool.length < 4) return;
    const qs = shuffle(pool.slice())
      .slice(0, 5)
      .map((w) => {
        const same = shuffle(pool.filter((o) => o.w !== w.w && o.c === w.c)).slice(0, 3);
        while (same.length < 3) {
          const r = pool[Math.floor(Math.random() * pool.length)];
          if (r.w !== w.w && !same.find((d) => d.w === r.w)) same.push(r);
        }
        return { w, opts: shuffle([w, ...same]) };
      });
    setRound({ qs, i: 0, score: 0, picked: null });
  }, [pool]);

  if (!round) {
    return (
      <div className="vq-idle">
        <div className="muted">ทาย 5 ข้อ — เห็นคำแปลไทย แล้วเลือกคำอังกฤษที่ถูก</div>
        <button className="vc-btn wide" onClick={start} disabled={pool.length < 4}>
          เริ่มเล่น
        </button>
      </div>
    );
  }

  const q = round.qs[round.i];
  if (!q) {
    return (
      <div className="vq-idle">
        <div className="vq-score">
          {round.score}
          <span>/{round.qs.length}</span>
        </div>
        <button className="vc-btn wide" onClick={start}>
          เล่นอีกรอบ
        </button>
      </div>
    );
  }

  const answered = round.picked != null;
  return (
    <div className="vq">
      <div className="vq-meta mono">
        <span>ข้อ {round.i + 1}/{round.qs.length}</span>
        <span>คะแนน {round.score}</span>
      </div>
      <div className="vq-prompt">{q.w.t}</div>
      <div className="vq-opts">
        {q.opts.map((o, i) => {
          let cls = "";
          if (answered) {
            if (o.w === q.w.w) cls = "right";
            else if (i === round.picked) cls = "wrong";
          }
          return (
            <button
              key={i}
              className={`vq-opt ${cls}`}
              disabled={answered}
              onClick={() =>
                setRound((r) => ({ ...r, picked: i, score: r.score + (o.w === q.w.w ? 1 : 0) }))
              }
            >
              {o.w}
            </button>
          );
        })}
      </div>
      {answered && (
        <div className="vq-after">
          <div className="vc-en">{q.w.e}</div>
          {q.w.x && <div className="muted">{q.w.x}</div>}
          <button
            className="vc-btn wide"
            onClick={() => setRound((r) => ({ ...r, i: r.i + 1, picked: null }))}
          >
            {round.i + 1 < round.qs.length ? "ข้อถัดไป" : "ดูผล"}
          </button>
        </div>
      )}
    </div>
  );
}

/* ── หน้าหลัก ── */
export default function VocabView() {
  const [base, setBase] = useState(null);
  const [custom, setCustom] = useState([]);
  const [known, setKnown] = useState([]);
  const [error, setError] = useState(null);
  const [bump, setBump] = useState(0); // ปุ่มสุ่มชุดใหม่
  const [q, setQ] = useState("");

  useEffect(() => {
    let dead = false;
    fetch(`${VOCAB_JSON}?t=${Date.now()}`)
      .then((r) => r.json())
      .then((j) => !dead && setBase(j.words ?? []))
      .catch(() => !dead && setError("โหลดคลังคำศัพท์ไม่ได้ — เช็คอินเทอร์เน็ต"));
    fetch(`${FS_VOCAB_URL}&t=${Date.now()}`)
      .then((r) => r.json())
      .then((d) => {
        if (dead) return;
        setCustom(fsWordsFromCustom(d.fields));
        setKnown(fsKnown(d.fields));
      })
      .catch(() => {});
    return () => {
      dead = true;
    };
  }, []);

  const all = useMemo(() => (base ?? []).concat(custom), [base, custom]);
  const knownSet = useMemo(() => new Set(known), [known]);

  const daily = useMemo(() => {
    if (!all.length) return [];
    const fresh = all.filter((w) => !knownSet.has(w.w.toLowerCase()));
    const src = fresh.length >= 5 ? fresh : all;
    const day = todayKey();
    const rnd = seedRandom(Number(day.replace(/-/g, "")) + bump * 7919);
    return shuffle(src.slice(), rnd).slice(0, 5);
  }, [all, knownSet, bump]);

  const markKnown = useCallback(
    (word) => {
      const k = word.toLowerCase();
      if (knownSet.has(k)) return;
      const next = known.concat(k);
      setKnown(next);
      pushKnown(next);
    },
    [known, knownSet]
  );

  const hits = useMemo(() => {
    const s = q.trim().toLowerCase();
    if (!s) return [];
    return all
      .filter((w) => `${w.w} ${w.t} ${w.e ?? ""} ${w.x ?? ""}`.toLowerCase().includes(s))
      .slice(0, 6);
  }, [q, all]);

  const doneToday = daily.filter((w) => knownSet.has(w.w.toLowerCase())).length;

  return (
    <div className="rows">
      <div className="band">
        <div className="row">
          <Panel title="5 คำวันนี้" defaultOpen right={daily.length ? `${doneToday}/${daily.length}` : ""}>
            {error && <div className="err">{error}</div>}
            {!base && !error && <div className="muted">กำลังโหลด…</div>}
            {daily.map((w) => (
              <Flash
                key={w.w}
                word={w}
                known={knownSet.has(w.w.toLowerCase())}
                onKnown={markKnown}
              />
            ))}
            {base && (
              <div className="vc-foot">
                <button className="vc-btn" onClick={() => setBump((b) => b + 1)}>
                  สุ่มชุดใหม่
                </button>
                <span className="stamp mono">จำได้สะสม {known.length} คำ</span>
              </div>
            )}
          </Panel>
        </div>

        <div className="row">
          <Panel title="เกมทายคำ" defaultOpen>
            {all.length ? <Quiz pool={all} /> : <div className="muted">กำลังโหลด…</div>}
          </Panel>

          <Panel title="ค้นหาคำศัพท์" defaultOpen right={all.length ? `${all.length} คำ` : ""}>
            <input
              className="vs-input"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="พิมพ์ได้ทั้งอังกฤษและไทย"
            />
            {q.trim() && !hits.length && <div className="muted">ไม่พบคำที่ค้นหา</div>}
            {hits.map((w) => (
              <div className="vs-hit" key={w.w}>
                <div className="vs-hit-top">
                  <span className="vc-w">{w.w}</span>
                  <span className="vc-t">{w.t}</span>
                </div>
                {w.e && <div className="vc-en">{w.e}</div>}
              </div>
            ))}
            <div className="vc-foot">
              <button className="vc-btn" onClick={() => openUrl(VOCAB_PAGE)}>
                เปิดคลังเต็มบนเว็บ ↗
              </button>
            </div>
          </Panel>
        </div>
      </div>
    </div>
  );
}
