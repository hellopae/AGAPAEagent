import { useCallback, useEffect, useMemo, useState } from "react";
import { invoke } from "@tauri-apps/api/core";
import { getCurrentWindow } from "@tauri-apps/api/window";
import { openUrl } from "@tauri-apps/plugin-opener";
import Panel from "./Panel";
import VocabView from "./Vocab";
import "./Team.css";
import { computeLevels } from "./levels";
import "./App.css";

const PAGES_BASE = "https://hellopae.github.io/AGAPAEagent";

/* จุดโฟกัสใบหน้าในรูป avatar ต่อคน — ค่าชุดเดียวกับที่ dashboard ใช้ (ฟิลด์ f ในตาราง ART)
   รูปเป็น 9:16 แต่การ์ดในแถวเป็นแนวนอน ถ้าครอปกลางรูปหน้าจะโดนตัด */
const FACE_Y = {
  claudy: 22, minnie: 26, reese: 20, addy: 25, rae: 25, vera: 28, mind: 24,
  chris: 24, libby: 33, nick: 35, dale: 27, toby: 28, news: 28,
};
const facePos = (id) => `50% ${FACE_Y[id] ?? 28}%`;
const POLL_MS = 5 * 60 * 1000; // 5 นาที (ห้ามต่ำกว่า 180 วิ ตาม brief ของ Reese)
const BTC_POLL_MS = 3 * 60 * 1000; // ตาม widget บน dashboard ของ Dale
const BTC_URL =
  "https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=usd,thb&include_24hr_change=true";
// Routines เขียน agents/daily·weekly·monthly — อ่านผ่าน Firestore REST (key เดียวกับ dashboard)
const FS_DOC_URL = (kind) =>
  `https://firestore.googleapis.com/v1/projects/agapae-studio/databases/(default)/documents/agents/${kind}?key=AIzaSyCtIZVYmibm4Rwb878iEdnxHjvpVcLfs2E`;
// แอป budget2569 เขียนสรุปการเงินเดือนปัจจุบันลง agents/finance (โชว์บน panel การเงิน + ปฏิทิน)
const FS_FINANCE_URL =
  "https://firestore.googleapis.com/v1/projects/agapae-studio/databases/(default)/documents/agents/finance?key=AIzaSyCtIZVYmibm4Rwb878iEdnxHjvpVcLfs2E";
const FIN_POLL_MS = 5 * 60 * 1000; // อัปเดตทุก 5 นาที (แอป budget push ทุกครั้งที่ใช้งาน)
// To Do — รายการจาก Todoist (project PAE To Do) มิเรอร์ไว้ที่ todo.json ใน repo AGAPAEagent
const TODO_URL = `${PAGES_BASE}/todo.json`;
const DASH_URL = `${PAGES_BASE}/`;
// เขียน limit ที่อ่านได้จริงกลับขึ้น Firestore ให้การ์ดบนเว็บใช้ตัวเลขเดียวกัน
const FS_LIMIT_URL =
  "https://firestore.googleapis.com/v1/projects/agapae-studio/databases/(default)/documents/agents/claude_limit?key=AIzaSyCtIZVYmibm4Rwb878iEdnxHjvpVcLfs2E";

/* แถบสลับหน้าบน titlebar — PAE จัดลำดับไว้แบบนี้ (10 ส.ค. 2569):
   การ์ดรายวัน · ทีม+worklog · การเงิน · คลังคำศัพท์ */
const VIEWS = [
  { id: "main", label: "AGAPAE WIDGET" },
  { id: "team", label: "TEAM AGAPAE", count: (c) => (c.agents ? `${c.agents}` : "") },
  { id: "finance", label: "การเงิน" },
  { id: "vocab", label: "VOCABULARY" },
];

const USAGE_ERROR_TEXT = {
  keychain_not_found:
    "ไม่พบ token ใน Keychain (Claude Code-credentials) — เปิด Claude Code แล้วล็อกอินก่อน",
  unauthorized: "token หมดอายุ — เปิด Claude Code สักครั้งเพื่อ refresh แล้วรอรอบถัดไป",
  rate_limited: "โดน rate limit ชั่วคราว — จะลองใหม่รอบถัดไป",
  network: "ต่ออินเทอร์เน็ตไม่ได้ — จะลองใหม่รอบถัดไป",
  schema: "endpoint เปลี่ยนโครงสร้าง (ไม่ official) — แจ้ง Dale ให้ปรับโค้ด",
};

function fmtTime(iso) {
  if (!iso) return "—";
  const d = new Date(iso);
  if (isNaN(d)) return "—";
  return d.toLocaleTimeString("th-TH", { hour: "2-digit", minute: "2-digit" });
}

function fmtDayTime(iso) {
  if (!iso) return "—";
  const d = new Date(iso);
  if (isNaN(d)) return "—";
  const day = d.toLocaleDateString("th-TH", { weekday: "short", day: "numeric", month: "short" });
  return `${day} ${fmtTime(iso)}`;
}

// วันที่+เวลาแบบสั้นสำหรับ badge (ข้อมูลไม่ได้อัปเดตแบบ real-time จึงบอก "อัปเดตเมื่อไหร่" แทนสถานะสด)
function fmtBadgeDate(iso) {
  if (!iso) return "—";
  const d = new Date(iso);
  if (isNaN(d)) return "—";
  const day = d.toLocaleDateString("th-TH", { day: "numeric", month: "short" });
  return `${day} ${fmtTime(iso)}`;
}

function barClass(pct) {
  if (pct >= 85) return "bar-fill crit";
  if (pct >= 60) return "bar-fill warn";
  return "bar-fill ok";
}

function LimitRow({ label, win, resetText }) {
  if (!win) return null;
  const pct = Math.max(0, Math.min(100, win.utilization));
  return (
    <div className="limit-row">
      <div className="limit-head">
        <span className="limit-label">{label}</span>
        <span className="limit-pct mono">{pct.toFixed(0)}%</span>
      </div>
      <div className="bar">
        <div className={barClass(pct)} style={{ width: `${pct}%` }} />
      </div>
      <div className="limit-reset mono">รีเซ็ต {resetText}</div>
    </div>
  );
}

const STATUS_TH = { working: "ทำงานอยู่", done: "เสร็จแล้ว", idle: "ว่าง", flagged: "รอแก้ไข", sent: "ส่งแล้ว" };

// วันที่แบบสั้น "12 ก.ค." (ไม่มีเวลา) สำหรับข้อมูลมังงะ
function fmtShortDate(iso) {
  if (!iso) return null;
  const d = new Date(iso);
  if (isNaN(d)) return null;
  return d.toLocaleDateString("th-TH", { day: "numeric", month: "short" });
}

// ประเมินสถานะตอนถัดไปของมังงะจาก nextAt → { cls, text }
function mangaNextStatus(s) {
  const relTxt = fmtShortDate(s.releasedAt);
  if (s.nextAt) {
    const next = new Date(s.nextAt);
    const due = !isNaN(next) && Date.now() >= next.getTime();
    if (due) return { cls: "out", text: `ตอน ${s.next} น่าจะออกแล้ว — เช็คเลย` };
    return { cls: "soon", text: `ตอนถัดไป ${s.next} · ${fmtShortDate(s.nextAt) ?? "เร็ว ๆ นี้"}` };
  }
  // ไม่รู้วันแน่นอน → บอกรอบออก + วันที่ตอนล่าสุด
  return { cls: "wait", text: `${s.cadence ?? "อัปเดตเรื่อย ๆ"}${relTxt ? " · ล่าสุด " + relTxt : ""}` };
}

function fmtUsd(n) {
  if (n == null) return "—";
  return n.toLocaleString("en-US", { maximumFractionDigits: 0 });
}

function fmtThb(n) {
  if (n == null) return "—";
  if (n >= 1e6) return `${(n / 1e6).toFixed(2)}M`;
  return n.toLocaleString("th-TH", { maximumFractionDigits: 0 });
}

// เงินบาทแบบมีทศนิยม 2 ตำแหน่ง (ให้ตรงกับการ์ดสรุปในแอป budget)
function fmtBaht(n) {
  if (n == null) return "—";
  return n.toLocaleString("th-TH", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

// อ่านค่าจาก Firestore typed fields
const fsNum = (f, k) => {
  const v = f?.[k];
  if (!v) return null;
  if (v.doubleValue != null) return Number(v.doubleValue);
  if (v.integerValue != null) return Number(v.integerValue);
  return null;
};
const fsStr = (f, k) => f?.[k]?.stringValue ?? null;
const fsIntArr = (f, k) =>
  (f?.[k]?.arrayValue?.values ?? []).map((x) => Number(x.integerValue ?? x.doubleValue)).filter((n) => !isNaN(n));

// อ่านก้อน JSON ที่ routine เขียนไว้ในฟิลด์ dataJson (แบบเดียวกับ daysJson ของ agents/finance)
// ใช้กับ agents/manga และ agents/todo — routine บน cloud push ขึ้น git ไม่ได้ (ยืนยัน 6 ส.ค. 2569)
// แต่เขียน Firestore ได้ทุกวัน ไฟล์ .json บน Pages จึงเหลือสถานะ fallback
// checkedAt = เวลาที่ routine มาตรวจล่าสุด เขียนทุกวันแม้ข้อมูลไม่เปลี่ยน
async function fsPayload(kind) {
  try {
    const res = await fetch(`${FS_DOC_URL(kind)}&t=${Date.now()}`);
    if (!res.ok) return null;
    const f = (await res.json()).fields ?? {};
    const raw = fsStr(f, "dataJson");
    if (!raw) return null;
    const data = JSON.parse(raw);
    data.checkedAt = fsStr(f, "checkedAt");
    return data;
  } catch {
    return null;
  }
}

// วันที่เหลือสิ้นเดือน คิดสดจาก "วันนี้" (สดทุกวันแม้แอป budget ยังไม่ push ใหม่)
function liveDaysLeft(fin) {
  const now = new Date();
  if (now.getFullYear() === fin.ceYear && now.getMonth() === fin.monthIdx && fin.daysInMonth) {
    return fin.daysInMonth - now.getDate() + 1;
  }
  return fin.daysLeft;
}

const TH_DOW = ["อา", "จ", "อ", "พ", "พฤ", "ศ", "ส"];

const dayItems = (fin, d) => (fin.dayMap && fin.dayMap[d]) || [];

// To Do ที่มีวันครบกำหนด → จัดลงวันของเดือนที่ปฏิทินกำลังแสดง (วัน → [item])
function todoByDay(todos, fin) {
  const map = {};
  for (const t of todos ?? []) {
    if (!t.due) continue;
    const d = new Date(`${t.due}T00:00:00`);
    if (isNaN(d) || d.getFullYear() !== fin.ceYear || d.getMonth() !== fin.monthIdx) continue;
    (map[d.getDate()] ??= []).push(t);
  }
  return map;
}

function FinanceCalendar({ fin, todos }) {
  const now = new Date();
  const todayD =
    now.getFullYear() === fin.ceYear && now.getMonth() === fin.monthIdx ? now.getDate() : -1;
  const [sel, setSel] = useState(todayD > 0 ? todayD : null);
  const dim = fin.daysInMonth;
  const first = fin.firstDow;
  if (!dim || first == null) return null;
  const inc = new Set(fin.incDays);
  const exp = new Set(fin.expDays);
  const todoMap = todoByDay(todos, fin);
  const cells = [];
  for (let i = 0; i < first; i++) cells.push(null);
  for (let d = 1; d <= dim; d++) cells.push(d);
  const selItems = sel ? dayItems(fin, sel) : [];
  const selTodos = sel ? todoMap[sel] ?? [] : [];
  return (
    <div className="fin-cal">
      <div className="fin-cal-dow">
        {TH_DOW.map((w, i) => (
          <span key={i} className={i === 0 ? "we" : ""}>{w}</span>
        ))}
      </div>
      <div className="fin-cal-grid">
        {cells.map((d, i) => (
          <button
            key={i}
            type="button"
            disabled={!d}
            onClick={() => d && setSel(d === sel ? null : d)}
            className={`fin-cell${d === todayD ? " today" : ""}${d === sel ? " sel" : ""}${d ? "" : " empty"}`}
          >
            {d && <span className="fin-day">{d}</span>}
            {d && (inc.has(d) || exp.has(d) || todoMap[d]) && (
              <span className="fin-dots">
                {inc.has(d) && <i className="dot inc" />}
                {exp.has(d) && <i className="dot exp" />}
                {todoMap[d] && <i className="dot todo" />}
              </span>
            )}
          </button>
        ))}
      </div>
      {sel && (
        <div className="fin-day-detail">
          <div className="fin-day-detail-head mono">
            {sel === todayD ? "วันนี้" : `วันที่ ${sel}`}
            {fin.monthLabel ? ` · ${fin.monthLabel}` : ""}
          </div>
          {selItems.length || selTodos.length ? (
            <ul className="fin-day-list">
              {selTodos.map((t) => (
                <li key={t.id}>
                  <span className="fin-di-name todo" title={t.title}>
                    {t.repeat && <span className="fin-di-rep">↻ </span>}
                    {t.title}
                  </span>
                  <span className="fin-di-tag mono">เตือน</span>
                </li>
              ))}
              {selItems.map((it, i) => (
                <li key={i}>
                  <span className={`fin-di-name ${it.t === "i" ? "inc" : "exp"}`}>{it.n}</span>
                  <span className={`fin-di-amt mono ${it.t === "i" ? "inc" : "exp"}`}>
                    {it.t === "i" ? "+" : "-"}{fmtBaht(it.a)}
                  </span>
                </li>
              ))}
            </ul>
          ) : (
            <div className="muted">
              {sel === todayD ? "วันนี้ยังไม่มีรายการ" : "ไม่มีรายการวันนี้"}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// สรุปแนวโน้ม BTC แบบเข้าใจง่าย (ย่อจาก investai) — รวม 5 สัญญาณเป็น % โอกาสขึ้น
function btcSignal(P) {
  const n = P.length, cur = P[n - 1];
  if (n < 60) return null;
  const sma = (a, p) => { if (a.length < p) return null; let s = 0; for (let i = a.length - p; i < a.length; i++) s += a[i]; return s / p; };
  const ma50 = sma(P, 50), ma200 = sma(P, 200);
  let g = 0, l = 0;
  for (let i = 1; i <= 14; i++) { const d = P[i] - P[i - 1]; d >= 0 ? (g += d) : (l -= d); }
  g /= 14; l /= 14;
  for (let i = 15; i < n; i++) { const d = P[i] - P[i - 1]; g = (g * 13 + (d > 0 ? d : 0)) / 14; l = (l * 13 + (d < 0 ? -d : 0)) / 14; }
  const rsi = l === 0 ? 100 : 100 - 100 / (1 + g / l);
  const mom20 = n > 20 ? (cur - P[n - 21]) / P[n - 21] : 0;
  const mom60 = n > 60 ? (cur - P[n - 61]) / P[n - 61] : 0;
  const cl = (x) => Math.max(-1, Math.min(1, x));
  const parts = [];
  if (ma50 != null) parts.push({ s: cl((cur - ma50) / ma50 / 0.08), w: 1.2, k: "ma50" });
  if (ma50 != null && ma200 != null) parts.push({ s: ma50 > ma200 ? 0.7 : -0.7, w: 1.3, k: "cross", golden: ma50 > ma200 });
  parts.push({ s: rsi > 70 ? -0.6 : rsi < 30 ? 0.7 : ((rsi - 50) / 30) * 0.4, w: 1.0, k: "rsi" });
  parts.push({ s: cl(mom20 / 0.15), w: 1.0, k: "mom20" });
  parts.push({ s: cl(mom60 / 0.30), w: 0.9, k: "mom60" });
  const totW = parts.reduce((a, p) => a + p.w, 0);
  const score = parts.reduce((a, p) => a + p.s * p.w, 0) / totW;
  const prob = Math.round(100 / (1 + Math.exp(-3.2 * score)));
  const up = prob >= 50;
  const top = [...parts].sort((a, b) => Math.abs(b.s * b.w) - Math.abs(a.s * a.w))[0];
  const nm = {
    ma50: "ราคาเทียบเส้น MA50",
    cross: top.golden ? "Golden Cross (แนวโน้มใหญ่ขึ้น)" : "Death Cross (แนวโน้มใหญ่ลง)",
    rsi: "RSI " + Math.round(rsi),
    mom20: "โมเมนตัม 20 วัน",
    mom60: "แนวโน้ม 60 วัน",
  };
  const reason = nm[top.k] + (top.k === "cross" ? "" : top.s > 0 ? " หนุนขึ้น" : " กดลง");
  const conf = Math.abs(prob - 50);

  // แนวรับ/แนวต้าน = ต่ำสุด/สูงสุดของ 90 วันหลังสุด
  const win = P.slice(-90);
  const low90 = Math.min(...win), high90 = Math.max(...win);
  const pct = (x) => `${x >= 0 ? "+" : ""}${(x * 100).toFixed(1)}%`;

  // คำวิเคราะห์ — ภาษาคนอ่านรู้เรื่อง ไม่ต้องรู้จักศัพท์เทคนิคมาก่อน
  const notes = [];
  if (ma50 != null) {
    const d50 = (cur - ma50) / ma50;
    notes.push(
      ma200 != null
        ? `ราคาอยู่${d50 >= 0 ? "เหนือ" : "ใต้"}เส้นเฉลี่ย 50 วัน ${pct(d50)} และ${cur >= ma200 ? "เหนือ" : "ใต้"}เส้น 200 วัน ${pct((cur - ma200) / ma200)}`
        : `ราคาอยู่${d50 >= 0 ? "เหนือ" : "ใต้"}เส้นเฉลี่ย 50 วัน ${pct(d50)}`
    );
  }
  if (ma50 != null && ma200 != null) {
    notes.push(
      ma50 > ma200
        ? "เส้น 50 วันอยู่เหนือเส้น 200 วัน (Golden Cross) — โครงสร้างใหญ่เป็นขาขึ้น"
        : "เส้น 50 วันยังอยู่ใต้เส้น 200 วัน (Death Cross) — โครงสร้างใหญ่ยังไม่กลับเป็นขาขึ้นเต็มตัว"
    );
  }
  const rsiTxt =
    rsi >= 70 ? "ร้อนแล้ว คนไล่ซื้อเยอะ เสี่ยงย่อ"
    : rsi <= 30 ? "ขายกันมากไป มีลุ้นเด้ง"
    : rsi >= 55 ? "แรงซื้อนำเล็กน้อย ยังไม่ร้อน"
    : rsi >= 45 ? "แรงซื้อ-ขายพอ ๆ กัน"
    : "แรงขายนำเล็กน้อย";
  notes.push(`RSI ${Math.round(rsi)} — ${rsiTxt}`);
  notes.push(`ผลตอบแทน 20 วัน ${pct(mom20)} · 60 วัน ${pct(mom60)}`);
  notes.push(`กรอบ 90 วัน — แนวรับ ~$${Math.round(low90).toLocaleString("en-US")} · แนวต้าน ~$${Math.round(high90).toLocaleString("en-US")}`);

  // คำแนะนำ — ผูกกับ prob + RSI ไม่ให้เชียร์ซื้อตอนราคาร้อนจัด
  let advice, adviceCls;
  if (prob >= 65 && rsi >= 70) {
    advice = "แนวโน้มดีแต่ราคาร้อนแล้ว — รอย่อค่อยเก็บ อย่าไล่ราคา";
    adviceCls = "warn";
  } else if (prob >= 65) {
    advice = "จังหวะสะสมได้ — แบ่งไม้ซื้อเป็นรอบ ๆ อย่าลงทีเดียวหมด";
    adviceCls = "good";
  } else if (prob >= 55) {
    advice = "ถือของเดิมไว้ ซื้อเพิ่มเฉพาะตอนราคาย่อลงมาใกล้แนวรับ";
    adviceCls = "good";
  } else if (prob >= 45) {
    advice = "สัญญาณก้ำกึ่ง — ยังไม่ต้องรีบ รอให้ทิศทางชัดก่อน";
    adviceCls = "";
  } else if (rsi <= 30) {
    advice = "ขาลงแต่ลงลึกมากแล้ว — รอสัญญาณกลับตัว อย่ารีบสวน";
    adviceCls = "warn";
  } else {
    advice = "ลดความเสี่ยงไว้ก่อน — ชะลอซื้อเพิ่ม รอแนวโน้มกลับด้าน";
    adviceCls = "bad";
  }

  return {
    prob, up, reason, notes, advice, adviceCls,
    rsi: Math.round(rsi), ma50, ma200, low90, high90,
    dirWord: up ? "มีโอกาสขึ้นมากกว่าลง" : "มีโอกาสลงมากกว่าขึ้น",
    confTxt: conf >= 18 ? "ค่อนข้างชัด" : conf >= 9 ? "พอมีน้ำหนัก" : "ยังก้ำกึ่ง",
  };
}

/* กราฟราคา BTC 90 วัน — เส้นราคา + เส้นเฉลี่ย 50 วัน (เส้นประ)
   วาดเป็น SVG ตรง ๆ ไม่พึ่ง lib กราฟ (แอปนี้ bundle เล็กไว้ก่อน) */
function BtcChart({ closes, days = 90 }) {
  if (!Array.isArray(closes) || closes.length < 30) return null;
  const n = Math.min(days, closes.length);
  const pts = closes.slice(-n);
  const base = closes.length - n;
  const ma = pts.map((_, i) => {
    const end = base + i + 1;
    if (end < 50) return null;
    let s = 0;
    for (let k = end - 50; k < end; k++) s += closes[k];
    return s / 50;
  });
  const all = pts.concat(ma.filter((v) => v != null));
  const lo = Math.min(...all), hi = Math.max(...all);
  const W = 280, H = 70, pad = 4;
  const X = (i) => (i / (n - 1)) * W;
  const Y = (v) => pad + (1 - (v - lo) / (hi - lo || 1)) * (H - pad * 2);
  const path = pts.map((v, i) => `${i ? "L" : "M"}${X(i).toFixed(1)},${Y(v).toFixed(1)}`).join("");
  const area = `${path}L${W},${H}L0,${H}Z`;
  let maPath = "", started = false;
  ma.forEach((v, i) => {
    if (v == null) return;
    maPath += `${started ? "L" : "M"}${X(i).toFixed(1)},${Y(v).toFixed(1)}`;
    started = true;
  });
  const up = pts[n - 1] >= pts[0];
  const col = up ? "var(--done)" : "var(--crit)";
  return (
    <div className="btc-chart">
      <svg viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none" role="img" aria-label="กราฟราคา BTC 90 วัน">
        <defs>
          <linearGradient id="btcFill" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={col} stopOpacity="0.26" />
            <stop offset="100%" stopColor={col} stopOpacity="0" />
          </linearGradient>
        </defs>
        <path d={area} fill="url(#btcFill)" />
        {maPath && <path d={maPath} fill="none" stroke="var(--gold)" strokeWidth="1" strokeDasharray="3 3" opacity="0.75" vectorEffect="non-scaling-stroke" />}
        <path d={path} fill="none" stroke={col} strokeWidth="1.5" vectorEffect="non-scaling-stroke" />
        <circle cx={X(n - 1)} cy={Y(pts[n - 1])} r="2.4" fill={col} vectorEffect="non-scaling-stroke" />
      </svg>
      <div className="btc-chart-legend mono">
        <span>90 วัน</span>
        <span className="sep">·</span>
        <span>ต่ำ ${fmtUsd(lo)}</span>
        <span className="sep">·</span>
        <span>สูง ${fmtUsd(hi)}</span>
        <span className="btc-chart-ma">— — MA50</span>
      </div>
    </div>
  );
}

// แถบกดเปิด-ปิด (accordion) — กดดูแต่ละส่วนได้ ไม่ต้องเลื่อน
/* ── To Do helpers ── */
function todoDaysLeft(item) {
  if (!item.due) return null;
  const d = new Date(`${item.due}T00:00:00`);
  if (isNaN(d)) return null;
  const now = new Date();
  now.setHours(0, 0, 0, 0);
  return Math.round((d - now) / 86400000);
}
const TODO_MONTHS = ["ม.ค.","ก.พ.","มี.ค.","เม.ย.","พ.ค.","มิ.ย.","ก.ค.","ส.ค.","ก.ย.","ต.ค.","พ.ย.","ธ.ค."];
// "2026-08-12" → "12 ส.ค. 69" (พ.ศ. 2 หลัก)
function todoDueText(due) {
  if (!due) return "";
  const d = new Date(`${due}T00:00:00`);
  if (isNaN(d)) return "";
  const be = String(d.getFullYear() + 543).slice(-2);
  return `${d.getDate()} ${TODO_MONTHS[d.getMonth()]} ${be}`;
}
function todoChipCls(n) {
  if (n === null) return "";
  if (n < 0) return "over";
  if (n <= 7) return "soon";
  return "";
}

/* ส่งตัวเลข limit ชุดเดียวกับที่การ์ดนี้แสดง ขึ้น Firestore agents/claude_limit
   → การ์ด "Claude Limit" บน dashboard จะตรงกับ Widget เป๊ะ (เดิมใช้ ccusage ประมาณเอา
   และอัปเดตเฉพาะตอน hook ทำงาน) · เขียนได้ก็ต่อเมื่อแอปเปิดอยู่ */
function pushLimitToFirestore(u) {
  if (!u?.five_hour) return;
  const fields = {
    fiveHourPct: { doubleValue: Math.round((u.five_hour.utilization ?? 0) * 10) / 10 },
    fiveHourResetAt: { stringValue: u.five_hour.resets_at ?? "" },
    sevenDayPct: { doubleValue: Math.round((u.seven_day?.utilization ?? 0) * 10) / 10 },
    sevenDayResetAt: { stringValue: u.seven_day?.resets_at ?? "" },
    source: { stringValue: "widget" },
    updatedAt: { stringValue: new Date().toISOString() },
  };
  const mask = Object.keys(fields).map((k) => `updateMask.fieldPaths=${k}`).join("&");
  fetch(`${FS_LIMIT_URL}&${mask}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ fields }),
  }).catch(() => {});
}

/* ===== LEVEL — ป้ายระดับ · เหรียญ · แถบ MVP =====
   ตัวเลขมาจาก computeLevels() ใน levels.js (worklog จริง ไม่มีตัวเลขปั้น) */
function LvPill({ v, dim }) {
  if (!v) return null;
  return (
    <span
      className={`lv-pill lv-${v.tier.key}${dim ? " dim" : ""}`}
      title={`EXP ${v.exp} · ปิดงานสะสม ${v.jobs} ชิ้น`}
    >
      {v.tier.emoji} LV {v.lv} · {v.tier.name}
    </span>
  );
}

function LvMarks({ v }) {
  if (!v) return null;
  const marks = [];
  if (v.mvp) marks.push(<span key="mvp" title={`MVP — ปิด ${v.week} งานใน 7 วันล่าสุด`}>👑</span>);
  if (v.streak >= 3) marks.push(<span key="st" title={`ทำงานติดกัน ${v.streak} วัน`}>🔥</span>);
  if (!marks.length) return null;
  return <span className="lv-marks">{marks}</span>;
}

function LvMvpBar({ mvp, levels, agents }) {
  if (!agents) return null;
  if (!mvp.length) {
    return (
      <div className="lv-mvp">
        <span className="crown">👑</span>
        <span className="lab mono">MVP</span>
        <span className="none">ยังไม่มีงานปิดใน 7 วันล่าสุด</span>
      </div>
    );
  }
  const who = mvp.map((id) => agents.find((a) => a.id === id)).filter(Boolean);
  if (!who.length) return null;
  return (
    <div className="lv-mvp">
      <span className="crown">👑</span>
      <span className="lab mono">MVP · 7 วันล่าสุด</span>
      {who.map((a) => (
        <img
          key={a.id}
          className="face"
          src={`${PAGES_BASE}/${a.img}`}
          alt={a.name}
          style={{ objectPosition: facePos(a.id) }}
          onError={(e) => (e.currentTarget.style.visibility = "hidden")}
        />
      ))}
      <span className="who">{who.map((a) => a.name).join(" · ")}</span>
      <LvPill v={levels[who[0].id]} />
      <span className="sp" />
      <span className="sub">ปิด {levels[who[0].id].week} งาน</span>
    </div>
  );
}

export default function App() {
  const [view, setView] = useState("main"); // ดู VIEWS ข้างบน
  /* ธีมสว่าง/มืด — จำไว้ใน localStorage ทั้งแอปอ้าง --ink/--paper อยู่แล้ว
     สลับค่าตัวแปรที่ :root[data-theme="light"] ใน App.css ทีเดียวเปลี่ยนทั้งแอป */
  const [theme, setTheme] = useState(() => localStorage.getItem("agapae.theme") || "dark");
  const [seen, setSeen] = useState({ main: true }); // แท็บที่เคยเปิดแล้ว (mount ค้างไว้)
  const [usage, setUsage] = useState({ data: null, error: null, at: null });
  const [team, setTeam] = useState({ agents: null, updatedAt: null, error: null });
  const [latest, setLatest] = useState(null);
  const [worklog, setWorklog] = useState(null);
  const [btc, setBtc] = useState(null);
  const [btcSig, setBtcSig] = useState(null);
  const [btcSeries, setBtcSeries] = useState(null); // ราคาปิดรายวัน สำหรับกราฟ
  const [routines, setRoutines] = useState({
    daily: null,
    weekly: null,
    monthly: null,
    email: null,
    article: null,
  });
  const [newsFallback, setNewsFallback] = useState(null);
  const [finance, setFinance] = useState(null);
  const [manga, setManga] = useState(null);
  const [todo, setTodo] = useState(null);
  const daily = routines.daily;

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    try { localStorage.setItem("agapae.theme", theme); } catch { /* โหมดส่วนตัวเขียนไม่ได้ ไม่เป็นไร */ }
  }, [theme]);

  const loadTodo = useCallback(async () => {
    try {
      // Firestore มาก่อน (routine เขียนได้ทุกวัน) — todo.json ในรีโปเป็น fallback ที่อาจเก่า
      let data = await fsPayload("todo");
      if (!data || !Array.isArray(data.items)) {
        const res = await fetch(`${TODO_URL}?t=${Date.now()}`);
        if (!res.ok) throw new Error("http");
        data = await res.json();
      }
      if (!Array.isArray(data.items)) throw new Error("schema");
      setTodo(data);
    } catch {
      setTodo((prev) => prev ?? { error: "โหลด To Do ไม่ได้" });
    }
  }, []);

  const loadFinance = useCallback(async () => {
    try {
      const res = await fetch(`${FS_FINANCE_URL}&t=${Date.now()}`);
      if (!res.ok) throw new Error("http");
      const f = (await res.json()).fields ?? {};
      // รายละเอียดรายวัน (วัน → [{t,n,a}]) จาก daysJson
      let dayMap = {};
      const daysJson = fsStr(f, "daysJson");
      if (daysJson) { try { dayMap = JSON.parse(daysJson); } catch { dayMap = {}; } }
      let incDays = fsIntArr(f, "incDays");
      let expDays = fsIntArr(f, "expDays");
      if (Object.keys(dayMap).length) {
        incDays = []; expDays = [];
        for (const [d, items] of Object.entries(dayMap)) {
          if (items.some((x) => x.t === "i")) incDays.push(Number(d));
          if (items.some((x) => x.t === "e")) expDays.push(Number(d));
        }
      }
      setFinance({
        monthLabel: fsStr(f, "monthLabel"),
        ceYear: fsNum(f, "ceYear"),
        monthIdx: fsNum(f, "monthIdx"),
        daysInMonth: fsNum(f, "daysInMonth"),
        firstDow: fsNum(f, "firstDow"),
        income: fsNum(f, "income"),
        expense: fsNum(f, "expense"),
        balance: fsNum(f, "balance"),
        net: fsNum(f, "net"),
        daysLeft: fsNum(f, "daysLeft"),
        incDays,
        expDays,
        dayMap,
        updatedAt: fsStr(f, "updatedAt"),
      });
    } catch {
      setFinance((prev) => prev ?? { error: true });
    }
  }, []);

  const loadUsage = useCallback(async () => {
    try {
      const data = await invoke("get_usage");
      setUsage({ data, error: null, at: new Date() });
      pushLimitToFirestore(data); // ให้การ์ด Claude Limit บนเว็บใช้ตัวเลขชุดเดียวกับการ์ดนี้
    } catch (e) {
      setUsage((prev) => ({ ...prev, error: String(e), at: new Date() }));
    }
  }, []);

  const loadTeam = useCallback(async () => {
    try {
      const t = Date.now();
      const [sRes, wRes] = await Promise.all([
        fetch(`${PAGES_BASE}/status.json?t=${t}`),
        fetch(`${PAGES_BASE}/worklog.json?t=${t}`),
      ]);
      if (!sRes.ok || !wRes.ok) throw new Error("http");
      const status = await sRes.json();
      const worklog = await wRes.json();
      setTeam({ agents: status.agents ?? [], updatedAt: status.updatedAt, error: null });
      setWorklog(worklog.entries ?? []);
      setLatest(worklog.entries?.[0] ?? null);
      setNewsFallback(worklog.entries?.find((e) => e.agent === "news") ?? null);
    } catch {
      setTeam((prev) => ({ ...prev, error: "โหลดข้อมูลทีมไม่ได้ — เช็คเน็ตแล้วรอรอบถัดไป" }));
    }
  }, []);

  const loadManga = useCallback(async () => {
    try {
      let j = await fsPayload("manga");
      if (!j || !Array.isArray(j.series)) {
        const res = await fetch(`${PAGES_BASE}/manga.json?t=${Date.now()}`);
        if (!res.ok) throw new Error("http");
        j = await res.json();
      }
      setManga({
        series: j.series ?? [],
        updatedAt: j.updatedAt,
        checkedAt: j.checkedAt ?? null,
        error: null,
      });
    } catch {
      setManga((prev) => prev ?? { series: null, error: "โหลดข้อมูลมังงะไม่ได้" });
    }
  }, []);

  const loadBtc = useCallback(async () => {
    try {
      const res = await fetch(BTC_URL);
      if (!res.ok) throw new Error("http");
      const j = await res.json();
      const b = j.bitcoin;
      if (!b?.usd) throw new Error("schema");
      setBtc({ usd: b.usd, thb: b.thb, change: b.usd_24h_change, at: new Date() });
    } catch {
      // คงราคาเดิมไว้ รอรอบถัดไป
    }
  }, []);

  // สรุปแนวโน้ม BTC จากแท่งเทียนรายวัน Binance (เหมือน investai)
  const loadBtcSig = useCallback(async () => {
    try {
      const res = await fetch("https://api.binance.com/api/v3/klines?symbol=BTCUSDT&interval=1d&limit=250");
      if (!res.ok) throw new Error("http");
      const j = await res.json();
      const closes = j.map((k) => +k[4]);
      setBtcSeries(closes);
      const sig = btcSignal(closes);
      if (sig) setBtcSig(sig);
    } catch {
      // เก็บผลเดิมไว้ รอรอบถัดไป
    }
  }, []);


  const loadRoutines = useCallback(async () => {
    // painpoint ถอดออก 5 ก.ย. 2569 — doc agents/painpoint ยังอยู่ครบ แค่ไม่มีพาเนลแล้ว
    for (const kind of ["daily", "weekly", "monthly", "email", "article"]) {
      try {
        const res = await fetch(`${FS_DOC_URL(kind)}&t=${Date.now()}`);
        if (res.status === 404) {
          setRoutines((prev) => ({ ...prev, [kind]: { missing: true } }));
          continue;
        }
        if (!res.ok) throw new Error("http");
        const doc = await res.json();
        const f = doc.fields ?? {};
        // เช็ค isArray ก่อน .map — doc รูปแบบเพี้ยนต้องได้ลิสต์ว่าง ไม่ใช่ throw จนการ์ดขาว
        const raw = f.items?.arrayValue?.values;
        const items = (Array.isArray(raw) ? raw : [])
          .map((v) => v?.stringValue)
          .filter((s) => typeof s === "string" && s.trim());
        setRoutines((prev) => ({
          ...prev,
          [kind]: {
            title: f.title?.stringValue ?? "สรุป",
            date: f.date?.stringValue ?? null,
            items,
            // มีเฉพาะ agents/email — จำนวนอีเมลใหม่ (kind อื่นได้ null เฉย ๆ)
            count: fsNum(f, "count"),
            updatedAt: f.updatedAt?.stringValue ?? f.updatedAt?.timestampValue ?? null,
          },
        }));
      } catch {
        setRoutines((prev) => ({ ...prev, [kind]: prev[kind] ?? { missing: true } }));
      }
    }
  }, []);

  useEffect(() => {
    loadUsage();
    loadTeam();
    loadRoutines();
    loadBtc();
    loadBtcSig();
    loadFinance();
    loadManga();
    loadTodo();
    const id = setInterval(() => {
      loadUsage();
      loadTeam();
      loadRoutines();
      loadManga();
      loadTodo();
    }, POLL_MS);
    const idBtc = setInterval(() => { loadBtc(); loadBtcSig(); }, BTC_POLL_MS);
    const idFin = setInterval(loadFinance, FIN_POLL_MS);
    return () => {
      clearInterval(id);
      clearInterval(idBtc);
      clearInterval(idFin);
    };
  }, [
    loadUsage,
    loadTeam,
    loadRoutines,
    loadBtc,
    loadBtcSig,
    loadFinance,
    loadManga,
    loadTodo,
  ]);

  // งานที่ยังไม่เสร็จ เรียงตามวันที่ใกล้ครบกำหนดสุด (ไม่มีกำหนด → ท้ายสุด)
  const todoOpen = (todo?.items ?? [])
    .filter((i) => !i.done)
    .map((i) => ({ ...i, n: todoDaysLeft(i) }))
    .sort((a, b) => (a.n ?? 99999) - (b.n ?? 99999));
  // จัดกลุ่มตาม section ของ Todoist (ลำดับตามไฟล์ = ลำดับใน Todoist)
  const todoGroups = (todo?.sections ?? [])
    .map((s) => ({ ...s, items: todoOpen.filter((i) => i.section === s.id) }))
    .filter((g) => g.items.length);


  /* อีเมลใหม่ — ตัวเลขบนหัวแถบ: ใช้ count จาก routine ถ้าเป็นตัวเลขจริง
     ถ้า count หาย/เพี้ยน ถอยไปนับจำนวนบรรทัดใน items แทน (ยังบอกอะไรได้อยู่ ไม่ใช่ค้างว่าง) */
  const email = routines.email;
  const emailCount = typeof email?.count === "number" && !isNaN(email.count) ? email.count : null;
  const emailRight =
    !email
      ? ""
      : email.missing
      ? "ยังไม่มี"
      : emailCount != null
        ? emailCount > 0
          ? `${emailCount} ฉบับ`
          : "ไม่มีใหม่"
        : email.items?.length
          ? `${email.items.length} ฉบับ`
          : "ไม่มีใหม่";
  /* count = 0 แล้ว routine ยังเขียน items ว่า "ยังไม่มีอีเมลใหม่" มา 1 บรรทัด —
     กรณีนั้นแสดงเป็นข้อความจาง ๆ ไม่ใช่ bullet (bullet ที่บอกว่าไม่มีอะไร อ่านแล้วสะดุด) */
  /* ?. ที่ items ด้วย — ตอน doc ยังไม่มี (routine ยังไม่เคยรัน) state เป็น { missing: true }
     ซึ่งไม่มี items เลย ถ้าเข้าถึงตรง ๆ จะ throw ตั้งแต่ตอน render แล้วขาวทั้งแอป ไม่ใช่แค่การ์ดนี้ */
  const emailHasMail = emailCount != null ? emailCount > 0 : (email?.items?.length ?? 0) > 0;

  const win = getCurrentWindow();
  const u = usage.data;
  /* EXP / LV / ระดับ / MVP — คิดจาก worklog จริงก้อนเดียวกับที่โชว์ด้านล่าง
     สูตรตรงกับ AGAPAE Agent/index.html แก้ที่ไหนต้องแก้อีกที่ให้ตรงกัน */
  const { levels, mvp } = useMemo(
    () => computeLevels(worklog, team.agents),
    [worklog, team.agents],
  );

  const counts = { agents: team.agents?.length ?? 0 };
  /* แต่ละแท็บ mount ครั้งแรกที่เปิด แล้วอยู่ยาวโดยซ่อนไว้ — ไม่ unmount
     เพราะจะเสีย state ที่ผู้ใช้ตั้งไว้ (พาเนลที่พับ/กาง, วันที่เลือกบนปฏิทิน)
     และ VocabView จะโหลด vocab.json ใหม่ทุกครั้งที่สลับกลับมา */
  const hide = (id) => (view === id ? undefined : { display: "none" });

  return (
    <div className="card">
      <header className="titlebar" data-tauri-drag-region>
        {/* แถบสลับหน้า — ที่ว่างข้าง ๆ ยังลากย้ายหน้าต่างได้เหมือนเดิม */}
        <div className="view-tabs">
          {VIEWS.map((v) => (
            <button
              key={v.id}
              className={`view-tab mono ${view === v.id ? "on" : ""}`}
              onClick={() => {
                setView(v.id);
                setSeen((s) => (s[v.id] ? s : { ...s, [v.id]: true }));
              }}
            >
              {v.label}
              {v.count != null && v.count(counts) !== "" && (
                <span className="view-tab-n">{v.count(counts)}</span>
              )}
            </button>
          ))}
        </div>
        <div className="win-btns">
          <button
            className="win-btn"
            title={theme === "dark" ? "สลับเป็นธีมสว่าง" : "สลับเป็นธีมมืด"}
            onClick={() => setTheme((t) => (t === "dark" ? "light" : "dark"))}
          >
            {theme === "dark" ? "☀" : "☾"}
          </button>
          <button className="win-btn" title="ย่อ" onClick={() => win.minimize()}>
            –
          </button>
          <button className="win-btn" title="ซ่อน (เปิดคืนจาก tray)" onClick={() => win.hide()}>
            ✕
          </button>
        </div>
      </header>

      <main className="body">
       {seen.vocab && (
         <div style={hide("vocab")}>
           <VocabView />
         </div>
       )}
       <div className="rows" style={hide("main")}>
        {/* ── แถวบน ── 3 คอลัมน์: [Claude·มังงะ] · [ข่าวเช้า·บทความ] · [Bitcoin·อีเมล]
            21 ส.ค. 2569 — ตัดการ์ดดูดวงออก แล้วย้าย Bitcoin มาแทนที่ (คอลัมน์ขวามีที่พอสำหรับกราฟ) */}
        <div className="band">
        <div className="row">
        <Panel
          title="CLAUDE LIMITS"
          defaultOpen
          right={u ? `${Math.round(u.five_hour?.utilization ?? 0)}% · ${Math.round(u.seven_day?.utilization ?? 0)}%` : ""}
        >
          {usage.error && !u && <div className="err">{USAGE_ERROR_TEXT[usage.error] ?? usage.error}</div>}
          {u && (
            <>
              <LimitRow label="Session (5 ชม.)" win={u.five_hour} resetText={fmtTime(u.five_hour?.resets_at)} />
              <LimitRow label="Weekly (7 วัน)" win={u.seven_day} resetText={fmtDayTime(u.seven_day?.resets_at)} />
              {usage.error && <div className="err small">{USAGE_ERROR_TEXT[usage.error] ?? usage.error}</div>}
            </>
          )}
          {!u && !usage.error && <div className="muted">กำลังโหลด…</div>}
          {usage.at && (
            <div className="stamp mono">
              อัปเดต {usage.at.toLocaleTimeString("th-TH", { hour: "2-digit", minute: "2-digit" })}
            </div>
          )}
        </Panel>

        <Panel
          title="อัปเดตมังงะ"
          defaultOpen
          right={manga?.series ? `${manga.series.length} เรื่อง` : ""}
        >
          {manga?.series ? (
            <div className="manga-list">
              {manga.series.map((s, i) => {
                const st = mangaNextStatus(s);
                return (
                  <button
                    key={i}
                    className="manga-row"
                    title={`เปิด ${s.source ?? "อ่านออนไลน์"}`}
                    onClick={() => s.url && openUrl(s.url)}
                  >
                    <div className="manga-main">
                      <span className="manga-title">{s.title}</span>
                      <span className="manga-latest mono">ตอนล่าสุด #{s.latest}</span>
                    </div>
                    <div className="manga-meta">
                      <span className={`manga-chip ${st.cls}`}>{st.text}</span>
                      {s.source && <span className="manga-src">{s.source} ↗</span>}
                    </div>
                    {s.note && <div className="manga-note">{s.note}</div>}
                  </button>
                );
              })}
              {/* แยก 2 เวลา: "ข้อมูล ณ" = ตอนใหม่ออกล่าสุด (นิ่งได้เป็นสัปดาห์)
                  "ตรวจ" = routine มาดูล่าสุด (ขยับทุกวัน) — ไม่งั้นการ์ดดูเหมือนค้างทั้งที่ปกติ */}
              {(manga.updatedAt || manga.checkedAt) && (
                <div className="stamp mono">
                  {manga.updatedAt && `ข้อมูล ณ ${fmtDayTime(manga.updatedAt)}`}
                  {manga.updatedAt && manga.checkedAt && " · "}
                  {manga.checkedAt && `ตรวจ ${fmtDayTime(manga.checkedAt)}`}
                </div>
              )}
            </div>
          ) : manga?.error ? (
            <div className="muted">{manga.error}</div>
          ) : (
            <div className="muted">กำลังโหลด…</div>
          )}
        </Panel>
        </div>

        <div className="row">
        <Panel title="ข่าวเช้า" right={daily?.date ?? ""}>
          {daily && !daily.missing && (
            <div className="news">
              <div className="news-title">{daily.title}</div>
              <ul className="news-list">
                {daily.items.slice(0, 6).map((t, i) => (
                  <li key={i}>{t}</li>
                ))}
              </ul>
              {daily.updatedAt && <div className="stamp mono">อัปเดต {fmtDayTime(daily.updatedAt)}</div>}
            </div>
          )}
          {daily?.missing && newsFallback && (
            <div className="news">
              <div className="news-title">{newsFallback.title}</div>
              <ul className="news-list">
                <li>{newsFallback.summary}</li>
              </ul>
              <div className="stamp mono">จาก worklog · {newsFallback.displayDate ?? "—"}</div>
            </div>
          )}
          {daily?.missing && !newsFallback && (
            <div className="muted">ยังไม่มีสรุปข่าววันนี้ — routine เขียนทุก 09:00</div>
          )}
          {!daily && <div className="muted">กำลังโหลด…</div>}
        </Panel>

        {/* แทน PAIN POINT เมื่อ 5 ก.ย. 2569 ตามที่ Kittanate สั่ง —
            routine เขียน agents/article สัปดาห์ละ 3 หัวข้อ · คลังเต็มอยู่บนเว็บแท็บ บทความ */}
        <Panel
          title="บทความ · หัวข้อสัปดาห์นี้"
          right={
            routines.article && !routines.article.missing
              ? routines.article.date ?? ""
              : "ยังไม่มี"
          }
        >
          {routines.article && !routines.article.missing && routines.article.items.length ? (
            <ul className="news-list">
              {routines.article.items.map((t, i) => (
                <li key={i}>{t}</li>
              ))}
            </ul>
          ) : (
            <div className="muted">ยังไม่มี — routine เสนอ 3 หัวข้อทุกเช้าวันจันทร์</div>
          )}
        </Panel>
        </div>

        <div className="row">
        <Panel title="BITCOIN" defaultOpen right={btc ? `$${fmtUsd(btc.usd)}` : ""}>
          <div className="btc-row">
            {btc ? (
              <>
                <span className="btc-price mono">${fmtUsd(btc.usd)}</span>
                <span className={`btc-change mono ${btc.change >= 0 ? "up" : "down"}`}>
                  {btc.change >= 0 ? "▲" : "▼"} {Math.abs(btc.change ?? 0).toFixed(1)}%
                </span>
                <span className="btc-thb mono">฿{fmtThb(btc.thb)}</span>
              </>
            ) : (
              <span className="muted">กำลังโหลด…</span>
            )}
          </div>

          <BtcChart closes={btcSeries} />

          {btcSig && (
            <>
              <div className={`btc-sig ${btcSig.up ? "up" : "dn"}`}>
                <div className="btc-sig-top">
                  <span className="btc-sig-dir">{btcSig.dirWord}</span>
                  <span className="btc-sig-prob">โอกาสขึ้น {btcSig.prob}%</span>
                </div>
                <div className="btc-sig-bar"><i style={{ width: `${btcSig.prob}%` }} /></div>
                <div className="btc-sig-sub">ความชัดเจน {btcSig.confTxt} · {btcSig.reason}</div>
              </div>

              <div className="btc-note-head mono">คำวิเคราะห์</div>
              <ul className="btc-notes">
                {btcSig.notes.map((t, i) => (
                  <li key={i}>{t}</li>
                ))}
              </ul>

              <div className={`btc-advice ${btcSig.adviceCls}`}>
                <span className="btc-advice-tag mono">แนะนำ</span>
                <span className="btc-advice-txt">{btcSig.advice}</span>
              </div>
              <div className="stamp mono">
                คำนวณจากแท่งเทียนรายวัน Binance · ไม่ใช่คำแนะนำการลงทุน ตัดสินใจเองทุกครั้ง
              </div>
            </>
          )}
          {!btcSig && btc && <div className="muted">กำลังคำนวณแนวโน้ม…</div>}

        </Panel>

        {/* อีเมลใหม่ — วางใต้การ์ด Bitcoin ตรง ๆ (เดิมอยู่ใต้ดูดวง)
            ⚠️ อ่านจาก agents/email เฉพาะ items / count / date / updatedAt เท่านั้น
            doc นี้เปิดอ่านได้ด้วย API key ที่ฝังในหน้าเว็บสาธารณะ — ฝั่ง routine ตกลงกันว่า
            items มีแค่ "ชื่อผู้ส่ง · เวลา" ไม่มีชื่อเรื่องอีเมล ฝั่งนี้จึงห้ามไปดึงฟิลด์อื่นเพิ่ม */}
        <Panel title="อีเมลใหม่" defaultOpen right={emailRight}>
          {email && !email.missing ? (
            emailHasMail && email.items?.length ? (
              <div className="news">
                <ul className="news-list">
                  {email.items.slice(0, 6).map((t, i) => (
                    <li key={i}>{t}</li>
                  ))}
                </ul>
                {email.updatedAt && (
                  <div className="stamp mono">อัปเดต {fmtDayTime(email.updatedAt)}</div>
                )}
              </div>
            ) : (
              <>
                <div className="muted">ยังไม่มีอีเมลใหม่</div>
                {email.updatedAt && (
                  <div className="stamp mono">เช็คล่าสุด {fmtDayTime(email.updatedAt)}</div>
                )}
              </>
            )
          ) : email?.missing ? (
            <div className="muted">ยังไม่มีข้อมูลอีเมล — รอ routine รอบเช้า 08:00</div>
          ) : (
            <div className="muted">กำลังโหลด…</div>
          )}
        </Panel>
        </div>

        </div>

        {/* ── แถวล่าง ── To Do เต็มความกว้าง
            (ทีม AGAPAE กับ การเงิน ย้ายไปเป็นแท็บของตัวเองแล้ว — 10 ส.ค. 2569) ── */}
        <div className="band">
        <div className="row">
        <Panel
          title="TO DO"
          defaultOpen
          right={todoOpen.length ? `${todoOpen.length} งาน` : ""}
        >
          {todo?.error && !todoOpen.length && <div className="err">{todo.error}</div>}
          {todoGroups.length > 0 && (
            <div className="todo-list">
              <div className="todo-groups">
              {todoGroups.map((g) => (
                <div className="todo-group" key={g.id}>
                  <div className="todo-group-head mono">
                    <span>{g.name}</span>
                    <span className="todo-group-n">{g.items.length}</span>
                  </div>
                  {g.items.map((i) => (
                    <div className="todo-row" key={i.id}>
                      <span className="todo-title" title={i.title}>
                        {i.repeat && <span className="todo-rep">↻ </span>}
                        {i.title}
                      </span>
                      <span className={`todo-chip mono ${todoChipCls(i.n)}`}>
                        {i.due ? todoDueText(i.due) : i.when}
                      </span>
                    </div>
                  ))}
                </div>
              ))}
              </div>
              {(todo?.updatedAt || todo?.checkedAt) && (
                <div className="stamp mono">
                  {todo.updatedAt && `รายการ ณ ${todo.updatedAt}`}
                  {todo.updatedAt && todo.checkedAt && " · "}
                  {todo.checkedAt && `ตรวจ ${fmtDayTime(todo.checkedAt)}`}
                </div>
              )}
            </div>
          )}
          {!todo && <div className="muted">กำลังโหลด…</div>}
        </Panel>
        </div>
        </div>
       </div>

       {/* ══════ แท็บ TEAM AGAPAE — การ์ดทีม + ผังออฟฟิศ (บน) · Work Log (ล่างเต็มความกว้าง) ══════ */}
       {seen.team && (
       <div className="rows" style={hide("team")}>
        <div className="band">
        <div className="row">
        <Panel title="ทีม AGAPAE" defaultOpen right={team.agents ? `${team.agents.length} คน` : ""}>
          {team.error && !team.agents && <div className="err">{team.error}</div>}
          {team.agents && (
            <>
              {/* MVP ประจำสัปดาห์ — คนที่ปิดงานมากที่สุดใน 7 วันล่าสุด */}
              <LvMvpBar mvp={mvp} levels={levels} agents={team.agents} />
              {/* การ์ดทีม — รูป · ชื่อ · สถานะ · งานล่าสุด (แบบเดียวกับบนเว็บ) */}
              <div className="tm-grid">
                {team.agents.map((a) => (
                  <div className="tm" key={a.id} title={`${a.name} — ${a.role ?? ""}`}>
                    <span className="tm-pic">
                      <img
                        src={`${PAGES_BASE}/${a.img}`}
                        alt={a.name}
                        style={{ objectPosition: facePos(a.id) }}
                        loading="lazy"
                        onError={(e) => (e.currentTarget.style.visibility = "hidden")}
                      />
                      <LvMarks v={levels[a.id]} />
                    </span>
                    <span className="tm-nm">{a.name}</span>
                    <LvPill v={levels[a.id]} />
                    <span className={`tm-st ${a.status}`}>
                      <span className="dot" />
                      {STATUS_TH[a.status] ?? a.status}
                    </span>
                    <span className="tm-up">
                      {a.report?.title || a.task || "ยังไม่มีงานค้าง"}
                    </span>
                  </div>
                ))}
              </div>
            </>
          )}
          {!team.agents && !team.error && <div className="muted">กำลังโหลด…</div>}
          {team.error && team.agents && <div className="err small">{team.error}</div>}
        </Panel>
        </div>
        </div>

        <div className="band">
        <div className="row">
        {/* Work Log — entries ใหม่อยู่บนสุดอยู่แล้วในไฟล์ ไม่ต้อง sort ซ้ำ
            แสดง 25 รายการล่าสุด ที่เหลือเปิดดูบน dashboard */}
        <Panel title="WORK LOG" defaultOpen right={worklog ? `${worklog.length} รายการ` : ""}>
          {!worklog && !team.error && <div className="muted">กำลังโหลด…</div>}
          {worklog && !worklog.length && <div className="muted">ยังไม่มีผลงานบันทึกไว้</div>}
          {worklog && worklog.length > 0 && (
            <div className="wl-list">
              {worklog.slice(0, 25).map((e) => (
                <details className="wl" key={e.id ?? `${e.datetime}-${e.title}`}>
                  <summary className="wl-head">
                    <span className="wl-when mono">
                      {e.displayDate ?? "—"}
                      {e.displayTime ? ` · ${e.displayTime}` : ""}
                    </span>
                    <span className="wl-agent">{e.agentName ?? e.agent}</span>
                    <span className="wl-title" title={e.title}>{e.title}</span>
                  </summary>
                  {e.summary && <div className="wl-sum">{e.summary}</div>}
                  {Array.isArray(e.files) && e.files.length > 0 && (
                    <div className="wl-files mono">{e.files.join(" · ")}</div>
                  )}
                </details>
              ))}
              <button className="vc-btn" onClick={() => openUrl(DASH_URL)}>
                เปิด Work Log เต็มบน dashboard ↗
              </button>
            </div>
          )}
        </Panel>
        </div>
        </div>
       </div>
       )}

       {/* ══════ แท็บ การเงิน — สรุปตัวเลขเดือนนี้ (บน) + ปฏิทินเต็มความกว้าง (ล่าง)
            PAE ขอเรียงบน-ล่างแทนซ้าย-ขวา เมื่อ 10 ส.ค. 2569 ปฏิทินจะได้พื้นที่กว้างขึ้น ══════ */}
       {seen.finance && (
       <div className="rows" style={hide("finance")}>
        <div className="band">
        <div className="row">
        <Panel
          title="สรุปเดือนนี้"
          defaultOpen
          right={finance && !finance.error ? finance.monthLabel ?? "" : ""}
        >
          {finance && !finance.error ? (
            <>
              <div className="fin-tiles">
                <div className="fin-tile">
                  <div className="fin-tile-l mono">รายรับรวม</div>
                  <div className="fin-tile-v in">฿{fmtBaht(finance.income)}</div>
                </div>
                <div className="fin-tile">
                  <div className="fin-tile-l mono">รายจ่ายรวม</div>
                  <div className="fin-tile-v ex">฿{fmtBaht(finance.expense)}</div>
                </div>
                <div className="fin-tile">
                  <div className="fin-tile-l mono">คงเหลือ</div>
                  <div className="fin-tile-v">฿{fmtBaht(finance.balance)}</div>
                </div>
                {/* net เป็นลบ = ขาดทุน · เป็นบวก = กำไร — ป้ายเปลี่ยนตามเครื่องหมาย
                    จะได้ไม่ต้องมีสองช่องที่บอกเรื่องเดียวกัน */}
                <div className="fin-tile">
                  <div className="fin-tile-l mono">
                    {(finance.net ?? 0) < 0 ? "ขาดทุน" : "กำไร"} · จำนวนสุทธิ
                  </div>
                  <div className={`fin-tile-v ${(finance.net ?? 0) < 0 ? "ex" : "in"}`}>
                    {(finance.net ?? 0) < 0 ? "−" : "+"}฿{fmtBaht(Math.abs(finance.net ?? 0))}
                  </div>
                </div>
              </div>
              {/* จำนวนวันที่เหลือไม่ต้องซ้ำตรงนี้ — พาเนลปฏิทินข้างล่างบอกอยู่แล้ว */}
              {finance.updatedAt && (
                <div className="stamp mono">อัปเดต {fmtDayTime(finance.updatedAt)}</div>
              )}
            </>
          ) : finance?.error ? (
            <div className="muted">ยังไม่มีข้อมูลการเงิน — เปิดแอป budget2569 สักครั้งเพื่อส่งข้อมูล</div>
          ) : (
            <div className="muted">กำลังโหลด…</div>
          )}
        </Panel>

        <Panel
          title="ปฏิทินรายรับรายจ่าย"
          defaultOpen
          right={finance && !finance.error ? `฿${fmtBaht(finance.balance)}` : ""}
        >
          {finance && !finance.error ? (
            <>
              {finance.monthLabel && (
                <div className="fin-sub mono">
                  {finance.monthLabel}
                  {liveDaysLeft(finance) != null && ` · เหลือ ${liveDaysLeft(finance)} วัน`}
                </div>
              )}
              <FinanceCalendar fin={finance} todos={todoOpen} />
            </>
          ) : finance?.error ? (
            <div className="muted">ยังไม่มีข้อมูลการเงิน — เปิดแอป budget2569 สักครั้งเพื่อส่งข้อมูล</div>
          ) : (
            <div className="muted">กำลังโหลด…</div>
          )}
        </Panel>
        </div>
        </div>
       </div>
       )}
      </main>

      <footer className="footer">
        {view === "vocab" && (
          <div className="latest">
            <span className="mono latest-tag">คลังคำ</span> กดคำเพื่อดูความหมาย · มาร์ก
            “จำได้แล้ว” แล้ววันหลังจะไม่สุ่มคำนั้นมาอีก
          </div>
        )}
        {view === "finance" && finance && !finance.error && (
          <div className="latest">
            <span className="mono latest-tag">การเงิน</span> ตัวเลขมาจากแอป budget2569 — แก้รายการในแอปนั้น
            แล้วการ์ดนี้จะอัปเดตตามภายใน 5 นาที
          </div>
        )}
        {(view === "main" || view === "team") && latest && (
          <div className="latest" title={latest.summary}>
            <span className="mono latest-tag">ล่าสุด</span> {latest.agentName}: {latest.title}
          </div>
        )}
        {(view === "main" || view === "team") && team.updatedAt && (
          <div className="stamp mono">ข้อมูลทีม ณ {fmtDayTime(team.updatedAt)}</div>
        )}
      </footer>
    </div>
  );
}
