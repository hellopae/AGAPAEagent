/* =====================================================================
   LEVEL — EXP / LV / ระดับ / MVP ประจำสัปดาห์
   ต้องให้ผลเท่ากับบนเว็บ (AGAPAE Agent/index.html หัวข้อเดียวกัน)
   ถ้าแก้สูตรที่นี่ ต้องแก้ที่ index.html ให้ตรงกันด้วย ไม่งั้นเลเวลจะไม่ตรง
   ===================================================================== */

/* EXP ต่องานหนึ่งชิ้น — งานที่ส่งออกไปแล้วได้มากกว่างานที่ยังติดปัญหา */
const LV_EXP = { sent: 12, done: 10, flagged: 4, blocked: 2 };
const LV_EXP_ANY = 6;

/* EXP ที่ต้องใช้ขึ้นเลเวลถัดไป — LV1→2 ใช้ 25 · LV10→11 ใช้ 70 */
export const lvNeed = (lv) => 20 + lv * 5;

export const LV_TIERS = [
  { key: "simple",   min: 1,  name: "Simple",   emoji: "🌱" },
  { key: "silver",   min: 5,  name: "Silver",   emoji: "🥈" },
  { key: "gold",     min: 10, name: "Gold",     emoji: "🥇" },
  { key: "platinum", min: 15, name: "Platinum", emoji: "🏆" },
  { key: "diamond",  min: 20, name: "Diamond",  emoji: "💎" },
];
export const lvTier = (lv) =>
  LV_TIERS.reduce((acc, t) => (lv >= t.min ? t : acc), LV_TIERS[0]);

export function lvFromExp(exp) {
  let lv = 1;
  let left = Math.max(0, exp | 0);
  while (lv < 99 && left >= lvNeed(lv)) {
    left -= lvNeed(lv);
    lv++;
  }
  return { lv, into: left, need: lvNeed(lv) };
}

/* วันที่แบบเวลาไทย (UTC+7) — worklog เก็บเป็น UTC */
const dayKey = (ms) => new Date(ms + 7 * 3600 * 1000).toISOString().slice(0, 10);
const WEEK_MS = 7 * 24 * 3600 * 1000;

/* ทำงานติดต่อกันกี่วัน — นับถอยจากวันนี้ (หรือเมื่อวาน ถ้าวันนี้ยังไม่มีงาน) */
function streakOf(days) {
  if (!days || !days.size) return 0;
  const now = Date.now();
  const start = days.has(dayKey(now))
    ? dayKey(now)
    : days.has(dayKey(now - 86400000))
      ? dayKey(now - 86400000)
      : null;
  if (!start) return 0;
  let n = 0;
  let t = Date.parse(start + "T00:00:00Z");
  while (days.has(new Date(t).toISOString().slice(0, 10))) {
    n++;
    t -= 86400000;
  }
  return n;
}

/**
 * คิดเลเวลของทุกคนจาก worklog จริง
 * @returns {{levels: Object, mvp: string[]}} levels[agentId] = {exp,jobs,week,lv,into,need,tier,streak,mvp}
 */
export function computeLevels(worklog, agents) {
  const now = Date.now();
  const stat = {};
  const days = {};

  (worklog ?? []).forEach((e) => {
    if (!e || !e.agent) return;
    const s = stat[e.agent] ?? (stat[e.agent] = { exp: 0, jobs: 0, week: 0 });
    s.exp += LV_EXP[e.status] ?? LV_EXP_ANY;
    s.jobs += 1;
    const t = Date.parse(e.datetime ?? "");
    if (isNaN(t)) return;
    if (now - t <= WEEK_MS) s.week += 1;
    (days[e.agent] ?? (days[e.agent] = new Set())).add(dayKey(t));
  });

  const levels = {};
  (agents ?? []).forEach((a) => {
    const s = stat[a.id] ?? { exp: 0, jobs: 0, week: 0 };
    const p = lvFromExp(s.exp);
    levels[a.id] = { ...s, ...p, tier: lvTier(p.lv), streak: streakOf(days[a.id]), mvp: false };
  });

  /* MVP — ปิดงานมากที่สุดใน 7 วันล่าสุด · เสมอกันได้หลายคน */
  const mvp = [];
  const top = Object.values(levels).reduce((m, v) => Math.max(m, v.week), 0);
  if (top > 0)
    Object.keys(levels).forEach((id) => {
      if (levels[id].week === top) {
        levels[id].mvp = true;
        mvp.push(id);
      }
    });

  return { levels, mvp };
}
