// AGAPAE Widget — Rust core
//
// ความปลอดภัย (กติกาเข้มงวด):
// - OAuth token อ่านสดจาก macOS Keychain ทุกครั้ง อยู่ในหน่วยความจำฝั่ง Rust เท่านั้น
// - ห้าม log / ห้ามเขียนลงไฟล์ / ห้ามส่ง token ข้ามไป frontend
// - frontend ได้เฉพาะตัวเลข % + เวลารีเซ็ต ที่ประมวลผลแล้ว

use serde::Serialize;
use std::process::Command;
use std::sync::OnceLock;
use std::time::Duration;

use tauri::{
    menu::{Menu, MenuItem},
    tray::TrayIconBuilder,
    Manager,
};

const USAGE_URL: &str = "https://api.anthropic.com/api/oauth/usage";
const KEYCHAIN_SERVICE: &str = "Claude Code-credentials";
// fallback ถ้าเรียก `claude --version` ไม่ได้ (ค่าจริงบนเครื่อง ณ วันที่พัฒนา)
const FALLBACK_CLI_VERSION: &str = "2.1.214";

#[derive(Serialize, Clone)]
pub struct LimitWindow {
    /// 0-100
    pub utilization: f64,
    /// ISO timestamp เวลารีเซ็ต (ถ้า endpoint ให้มา)
    pub resets_at: Option<String>,
}

#[derive(Serialize, Clone)]
pub struct UsageData {
    pub five_hour: Option<LimitWindow>,
    pub seven_day: Option<LimitWindow>,
}

/// อ่าน OAuth access token จาก macOS Keychain — อ่านสดทุกครั้ง ไม่ cache
/// (Claude Code refresh token เองเป็นระยะ ค่าใน Keychain จะใหม่เสมอ)
fn read_access_token() -> Result<String, String> {
    let out = Command::new("security")
        .args(["find-generic-password", "-s", KEYCHAIN_SERVICE, "-w"])
        .output()
        .map_err(|_| "keychain_not_found".to_string())?;
    if !out.status.success() {
        return Err("keychain_not_found".into());
    }
    let raw = String::from_utf8_lossy(&out.stdout);
    let json: serde_json::Value =
        serde_json::from_str(raw.trim()).map_err(|_| "keychain_not_found".to_string())?;
    json.get("claudeAiOauth")
        .and_then(|o| o.get("accessToken"))
        .and_then(|t| t.as_str())
        .map(|s| s.to_string())
        .ok_or_else(|| "keychain_not_found".into())
}

/// version ของ Claude Code CLI สำหรับ User-Agent (จำเป็น ไม่งั้นโดน 429)
fn claude_cli_version() -> &'static str {
    static VERSION: OnceLock<String> = OnceLock::new();
    VERSION.get_or_init(|| {
        Command::new("claude")
            .arg("--version")
            .output()
            .ok()
            .filter(|o| o.status.success())
            .and_then(|o| {
                String::from_utf8_lossy(&o.stdout)
                    .split_whitespace()
                    .next()
                    .map(|v| v.to_string())
            })
            .unwrap_or_else(|| FALLBACK_CLI_VERSION.to_string())
    })
}

fn parse_window(value: &serde_json::Value, key: &str) -> Option<LimitWindow> {
    let obj = value.get(key)?;
    let utilization = obj.get("utilization")?.as_f64()?;
    let resets_at = obj
        .get("resets_at")
        .and_then(|r| r.as_str())
        .map(|s| s.to_string());
    Some(LimitWindow {
        utilization,
        resets_at,
    })
}

/// ดึง % limit จาก oauth/usage endpoint — คืนเฉพาะข้อมูลที่ประมวลแล้ว
/// error codes: keychain_not_found | unauthorized | rate_limited | network | schema
#[tauri::command]
async fn get_usage() -> Result<UsageData, String> {
    let token = read_access_token()?;

    let client = reqwest::Client::builder()
        .timeout(Duration::from_secs(15))
        .build()
        .map_err(|_| "network".to_string())?;

    let resp = client
        .get(USAGE_URL)
        .bearer_auth(&token)
        .header(
            "User-Agent",
            format!("claude-code/{}", claude_cli_version()),
        )
        .header("Accept", "application/json")
        .send()
        .await
        .map_err(|_| "network".to_string())?;

    match resp.status().as_u16() {
        200 => {}
        401 | 403 => return Err("unauthorized".into()),
        429 => return Err("rate_limited".into()),
        _ => return Err("schema".into()),
    }

    let body: serde_json::Value = resp.json().await.map_err(|_| "schema".to_string())?;
    let five_hour = parse_window(&body, "five_hour");
    let seven_day = parse_window(&body, "seven_day");

    if five_hour.is_none() && seven_day.is_none() {
        // โครงสร้าง response เปลี่ยน — endpoint นี้ไม่ official
        return Err("schema".into());
    }

    Ok(UsageData {
        five_hour,
        seven_day,
    })
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .plugin(tauri_plugin_opener::init())
        .plugin(tauri_plugin_window_state::Builder::default().build())
        .invoke_handler(tauri::generate_handler![get_usage])
        .setup(|app| {
            // widget mode: ไม่โชว์ไอคอนบน Dock — เข้าถึงผ่าน tray แทน
            #[cfg(target_os = "macos")]
            app.set_activation_policy(tauri::ActivationPolicy::Accessory);

            let toggle =
                MenuItem::with_id(app, "toggle", "แสดง / ซ่อนการ์ด", true, None::<&str>)?;
            let quit = MenuItem::with_id(app, "quit", "ออกจากแอป", true, None::<&str>)?;
            let menu = Menu::with_items(app, &[&toggle, &quit])?;

            TrayIconBuilder::with_id("agapae-tray")
                .icon(app.default_window_icon().unwrap().clone())
                .icon_as_template(true)
                .menu(&menu)
                .show_menu_on_left_click(true)
                .on_menu_event(|app, event| match event.id.as_ref() {
                    "toggle" => {
                        if let Some(w) = app.get_webview_window("main") {
                            if w.is_visible().unwrap_or(false) {
                                let _ = w.hide();
                            } else {
                                let _ = w.show();
                                let _ = w.set_focus();
                            }
                        }
                    }
                    "quit" => app.exit(0),
                    _ => {}
                })
                .build(app)?;

            Ok(())
        })
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
