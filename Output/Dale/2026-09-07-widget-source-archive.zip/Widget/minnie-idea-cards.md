# Widget Project — Minnie's Idea Cards

**จาก:** Minnie (Ideas & Concepts, AGAPAE AI Studio)
**วันที่:** 18 ก.ค. 2026
**โจทย์:** Claude Usage Widget ฉบับ Kittanate บน **macOS** — บอก limit Claude ที่เหลือ + อัปเดตงานทีม AGAPAE + เปิดกว้าง "และอื่นๆ"
**ต้นแบบ:** Widget ของ Claude Thailand Community (Windows, การ์ดลอย, RGB 16 ล้านสี, PNG mascot, refresh 5 นาที)

> ⚠️ ทุก card เป็น **สมมติฐาน** — technical facts ที่ยังไม่ยืนยันถูกตั้งเป็น Research Questions ให้ Reese ทั้งหมด ห้ามเอาไปอ้างเป็นข้อสรุปจนกว่า Reese จะเช็ค

ข้อมูลที่ยืนยันแล้วจากระบบเรา (Minnie เช็คไฟล์จริง):
- Dashboard มีอยู่แล้วที่ https://hellopae.github.io/AGAPAEagent/ อ่านจาก `worklog.json` + `status.json` + Firestore (`agents/worklog`)
- `status.json` มี per-agent: `id, name, role, pipeline, img (avatars/*.png), persona, status, task, report{when,title,body}`
- `worklog.json` มี entries: `datetime, displayDate/Time (พ.ศ.), agent, agentImg, pipeline, status, title, summary`
- Avatar mascot ของทุก agent มีแล้วใน `AGAPAE Agent/avatars/`

---

## Card 1 — "Pae's Pocket Shrine" 🏮
### ศาลพระภูมิจิ๋วบน Menu Bar (เล็กสุด ใช้ได้จริงใน 1 วัน)

**Concept:** ไอคอนเล็กๆ บน menu bar ของ Mac แสดงตัวเลขเดียวที่สำคัญที่สุด — "% limit Claude ที่เหลือ" — คลิกแล้ว dropdown เป็นการ์ดเล็กๆ สไตล์ศาลพระภูมิ/หิ้งพระจิ๋ว: แถบ usage ของ session + weekly, ใต้ลงมาคือแถวหน้า mascot ทีม AGAPAE พร้อมสถานะงานล่าสุด 1 บรรทัดต่อคน ดึงจาก `status.json` บน GitHub Pages ที่มีอยู่แล้ว ไม่ต้องสร้าง backend ใหม่เลย

**ข้อมูลที่แสดง**
- *Claude usage:* % session ปัจจุบัน + เวลารีเซ็ต, % weekly (ตัวเลขบน menu bar = ค่าที่วิกฤตสุด)
- *งาน Agent:* ชื่อ + status ล่าสุดจาก `status.json` (แค่ done/working + title)
- *อื่นๆ:* ไม่มี — ตั้งใจตัดทิ้งให้เหลือแก่นเดียว

**รูปแบบ:** Menu bar app (สมมติฐาน: ใช้เครื่องมือตระกูล xbar/SwiftBar ที่เขียน plugin เป็น shell/JS ได้ — Reese ต้องยืนยัน) — เหมาะเพราะ menu bar คือที่ที่ "เหลือบมองได้ตลอด" โดยไม่กินพื้นที่จอ ตรงกับ use case เช็ค limit ระหว่างทำงาน

**Hypothesis:** Kittanate จะใช้ทุกวันเพราะคำถามที่ถามบ่อยที่สุดคือ "เหลือ limit เท่าไหร่ / ใครทำงานเสร็จแล้ว" — ถ้าตอบได้ใน 1 เหลือบตาโดยไม่ต้องเปิดแท็บใหม่ มันจะกลายเป็น reflex

**Research questions ให้ Reese**
1. ข้อมูล limit ของ Claude Code/Claude desktop ดึงจากไหนได้จริง? มีไฟล์ local ใน `~/.claude/` หรือ endpoint ที่ community tools (เช่นตัวที่ Claude Thailand ใช้) อ่านกัน? อ่านยังไง ต้อง auth ไหม?
2. คำสั่ง `/usage` ใน Claude Code เอาข้อมูลมาจากไหน — มีทางเรียกแบบ programmatic ไหม?
3. xbar / SwiftBar ยัง maintain อยู่ไหมในปี 2026, ติดตั้งยากไหม, plugin เขียนภาษาอะไรได้บ้าง, refresh interval ตั้งได้เองไหม?
4. `status.json` บน GitHub Pages มี CORS/caching อะไรที่ทำให้ข้อมูลค้างเกิน 5 นาทีไหม?

**ความยาก: S** (ถ้าคำตอบข้อ 1 มีทางดึงง่าย — ถ้าไม่มี ตัวเลข Claude อาจต้องเป็น phase 2 แล้ววันแรก ship เฉพาะฝั่ง agent status ก่อน)

---

## Card 2 — "AGAPAE Desk Companion" 🎏
### มาสคอตลอยบนจอ แบบเดียวกับต้นแบบ Windows แต่จิตวิญญาณอนิเมะเต็มระบบ

**Concept:** หน้าต่างลอย always-on-top มุมจอ เป็นการ์ดโปร่งแสงสไตล์อนิเมะ มี mascot ประจำการ์ด (เลือกได้จาก avatar ทีม 10 ตัวที่มีอยู่แล้ว หรือแอด PNG เองแบบต้นแบบ) — วงแหวน usage ล้อมตัว mascot, การ์ดสลับหน้าได้: หน้า Claude limits / หน้าทีม AGAPAE / หน้า worklog ล่าสุด ปรับสีการ์ดได้อิสระ (เทียบฟีเจอร์ RGB ของต้นแบบ) นี่คือ "ตัวเดียวกับที่เห็นใน community แต่เป็นของเราและเป็น Mac"

**ข้อมูลที่แสดง**
- *Claude usage:* context %, session % + reset, weekly ทุก model (feature parity กับต้นแบบ)
- *งาน Agent:* mascot ตัวที่กำลัง working จะ "ตื่น" (เด้ง/เรืองแสง), เสร็จงานมี badge + title
- *อื่นๆ:* ธีมการ์ดตามวันพระ/วันสำคัญไทย (เปลี่ยนสีอัตโนมัติ — ของแต่งที่ต้นแบบไม่มี)

**รูปแบบ:** Floating window (สมมติฐาน: Electron หรือ Tauri ทำ frameless + always-on-top + transparent ได้ — Reese ยืนยัน) — เหมาะเพราะตรง mental model ของต้นแบบที่ Kittanate เห็นแล้วอยากได้ และเป็นพื้นที่เดียวที่ mascot อนิเมะแสดงตัวได้เต็มที่

**Hypothesis:** คุณค่าจริงไม่ใช่ตัวเลข แต่คือ "ทีมมีตัวตนอยู่บนจอ" — ถ้าเห็น Minnie/Dale ขยับเวลาทำงานอยู่ Kittanate จะเปิดทิ้งไว้ทุกวันเพราะผูกพัน ไม่ใช่เพราะ utility อย่างเดียว

**Research questions ให้ Reese**
1. Electron vs Tauri บน macOS 2026: ตัวไหนทำ transparent always-on-top window + กิน RAM น้อยกว่า? มีทางเลือกที่เบากว่า (เช่น web wrapper อื่น) ไหม?
2. ต้นแบบของ Claude Thailand Community ดึง usage data ด้วยวิธีไหน (open source ไหม? มี repo ให้แกะไหม?) — ถ้าแกะได้ ประหยัดงาน research ข้อ limit ทั้งหมด
3. แอปลอยแบบนี้โดน macOS จัดการยังไงตอน fullscreen/Spaces — always-on-top ทำงานข้าม Space ได้ไหม?
4. อ่าน Firestore `agents/worklog` แบบ realtime จากแอป desktop ต้องใช้ key/rules แบบไหน ปลอดภัยไหมถ้าฝัง config ในแอป?

**ความยาก: M**

---

## Card 3 — "Studio Pulse" 📊
### หน้า /widget บน dashboard เดิม — ไม่ต้องลงแอปอะไรเลย

**Concept:** เพิ่มหน้า compact view ให้ dashboard AGAPAEagent ที่มีอยู่ (เช่น `/widget.html`) — layout แนวตั้งแคบๆ ออกแบบมาให้เปิดเป็นหน้าต่าง browser เล็กๆ ข้างจอ หรือ (สมมติฐานให้ Reese เช็ค) ใช้ฟีเจอร์ "Add to Dock" ของ Safari ให้กลายเป็น web app แยกไอคอนเหมือนแอปจริง ได้ realtime จาก Firestore ฟรีเพราะ dashboard ทำ pipe นี้ไว้แล้ว ฝั่ง Claude limits ถ้ายังดึง live ไม่ได้ ให้เริ่มจากกรอกมือ/อัปเดตผ่าน hook ไปก่อน

**ข้อมูลที่แสดง**
- *Claude usage:* การ์ดบนสุด (แหล่งข้อมูลรอ Reese — อาจ manual ใน phase แรก)
- *งาน Agent:* ฟีดเดียวกับ dashboard แต่ย่อ: avatar + status dot + งานล่าสุด 1 บรรทัด
- *อื่นๆ:* ลิงก์ด่วนไปโปรเจกต์ที่แต่ละ agent เพิ่ง push (ดึงจาก summary ใน worklog)

**รูปแบบ:** Web (ต่อยอด repo เดิม, deploy Pages เดิม) — เหมาะเพราะ stack นี้ทีมเราชำนาญสุด (Vite/React/Firestore/Pages มี SOP ครบ), Dale ทำได้เลยไม่ต้องเรียนของใหม่ และใช้ได้จากทุกเครื่องรวมถึงมือถือ

**Hypothesis:** Kittanate เปิด dashboard อยู่แล้วเป็นประจำ — ถ้ามี view ที่ "เล็กพอจะเปิดค้างข้างจอ" จะเปลี่ยนจากการเปิดดูเป็นครั้งๆ เป็นเปิดค้างทั้งวัน

**Research questions ให้ Reese**
1. Safari "Add to Dock" (web app บน macOS) รองรับหน้าต่างขนาดเล็ก + auto-refresh/notification ได้แค่ไหน? Chrome PWA install บน macOS เทียบแล้วอันไหนเหมาะกว่า?
2. Browser window ทำ always-on-top บน macOS ได้ไหม หรือต้องพึ่งเครื่องมือเสริม (มีตัวไหนที่คนนิยม)?
3. มีทางให้ hook `hook-status.mjs` เขียนข้อมูล Claude usage ลง Firestore เพิ่มได้ไหม (อ่านจากไหนได้บ้างในเครื่อง ณ ตอน hook ทำงาน)?

**ความยาก: S–M** (S ถ้าเอาเฉพาะฝั่ง agent, +M เมื่อรวม usage จริง)

---

## Card 4 — "Merit Meter" 🪷
### เปลี่ยนตัวเลข limit ให้เป็นบาตรบุญ — widget ที่เป็นของเราคนเดียวในโลก

**Concept:** ทุก widget ในตลาดแสดง % กับ progress bar เหมือนกันหมด — ใบนี้ตีความใหม่ตาม aesthetic พุทธไทย: limit ที่เหลือ = "น้ำในบาตร" ค่อยๆ พร่องเมื่อใช้ และเติมเต็มเมื่อรีเซ็ต, งานที่ agent ทำเสร็จ = "ใบโพธิ์" ร่วงสะสมใต้ต้น, ครบสัปดาห์สรุปเป็น "บุญที่ทำ" (งานที่ ship) เป็น layer ภาพ (visual skin) ที่ครอบ engine จาก Card 1 หรือ 3 ได้เลย ไม่ใช่แอปแยก — เสนอเป็น "หน้าตา phase 2" ของใบที่ชนะ

**ข้อมูลที่แสดง**
- *Claude usage:* ระดับน้ำในบาตร (session) + ดวงจันทร์ข้างขึ้นข้างแรม (weekly cycle)
- *งาน Agent:* ใบโพธิ์ร่วง 1 ใบ/งานเสร็จ พร้อมสี ประจำ agent
- *อื่นๆ:* วันพระถัดไป + วันสำคัญทางพุทธจากปฏิทินไทย

**รูปแบบ:** Skin/theme บน format ของ Card 1 หรือ 3 — เหมาะเพราะแยกความเสี่ยง: engine ต้องเวิร์กก่อน ความงามค่อยตามมา และให้ Mind/Vera ทำงานคู่ขนานได้ทันทีระหว่างรอ research

**Hypothesis:** ของที่สวยและมีความหมายส่วนตัวจะไม่ถูกปิดทิ้ง — และถ้าออกมาดีพอ มันคือ portfolio piece ที่แชร์กลับเข้า Claude Thailand Community ได้ (คนทำ widget แจก → เราทำ widget ที่มีตัวตนแบบไทย) อาจกลายเป็น template ขายบน Gumroad ด้วยซ้ำ

**Research questions ให้ Reese**
1. ปฏิทินวันพระ/วันสำคัญพุทธ มี API หรือ data source ที่เชื่อถือได้ไหม (ต้องแม่นเรื่องข้างขึ้นข้างแรมไทย ไม่ใช่ lunar จีน)?
2. มี widget/แอปแนว "spiritual metaphor สำหรับ productivity data" ในตลาดไหม — เราจะได้รู้ว่า unique จริงหรือมีบทเรียนให้ลอก
3. ถ้าจะแจก community หรือขาย: license ของ asset ที่ Mind วาด + ข้อจำกัดการแจกแอปที่แตะข้อมูล Claude มีอะไรต้องระวังไหม?

**ความยาก: M** (บน engine ที่มีแล้ว; L ถ้าทำ animation เต็ม)

---

## Card 5 — "AGAPAE Command Deck" 🎛️ (ฝันใหญ่ — รวมทุกอย่าง)
### ศูนย์บัญชาการชีวิต Kittanate ทั้งใบในจอเดียว

**Concept:** วิวัฒนาการสุดท้ายของทุก card — แอป Mac ตัวเดียว (menu bar + หน้าต่างขยายได้) ที่เป็น "หน้าปัดชีวิต": Claude limits ทุกมิติ, ทีม AGAPAE ทั้ง 10 ตัวแบบ realtime พร้อม mascot, งานโรงพิมพ์ TANAPAT, ยอดขาย Etsy/Gumroad, ปฏิทินนัดลูกค้า, สรุปข่าวเช้าจาก routine 09:00 — พร้อม notification เมื่อ agent ทำงานเสร็จหรือ limit ใกล้หมด และปุ่ม action สั่งงานสั้นๆ กลับเข้าทีมได้จาก widget เลย

**ข้อมูลที่แสดง**
- *Claude usage:* ครบทุกอย่างแบบต้นแบบ + แจ้งเตือน threshold (เช่น เหลือ 20%)
- *งาน Agent:* status + worklog realtime + notification "Dale push แล้ว ✓"
- *อื่นๆ (จุดขายของใบนี้):* ยอดขาย Etsy/Gumroad วันนี้/สัปดาห์นี้ (ผ่าน Nick), คิวงานพิมพ์ลูกค้า TANAPAT, Google Calendar วันนี้, หัวข้อข่าวเช้าจาก routine

**รูปแบบ:** Native-feel Mac app (menu bar เป็นประตู + หน้าต่าง deck แบบขยาย) — use case นี้ต้องการ notification + ทำงานเบื้องหลัง + ความรู้สึก "เครื่องมือประจำตัว" ซึ่งเว็บให้ไม่สุด

**Hypothesis:** ตอนนี้ Kittanate ต้องเปิด 4-5 ที่เพื่อรู้สถานะชีวิต (dashboard, Etsy, Gumroad, ปฏิทิน, Claude) — ถ้าเหลือที่เดียว มันจะเป็นแอปแรกที่เปิดทุกเช้าและตัวชี้วัดว่า AGAPAE Studio "โตเป็นระบบปฏิบัติการของธุรกิจ" แล้วจริงๆ

**Research questions ให้ Reese**
1. Etsy API + Gumroad API ปี 2026: ขอ key ยากไหม, ดึงยอดขายรายวันได้ไหม, rate limit เท่าไหร่? (โยง Target stack ที่วางไว้อยู่แล้ว)
2. คิวงานพิมพ์ TANAPAT ตอนนี้เก็บอยู่ที่ไหนบ้าง (ระบบไหน/ไฟล์ไหน) — มีอะไร integrate ได้เลยโดยไม่ต้องสร้างระบบใหม่?
3. macOS notification จากแอปประเภทไหนบ้างที่ส่งได้โดยไม่ต้องผ่าน App Store/notarization — ข้อจำกัดของแอปที่ไม่ได้ sign คืออะไร?
4. "ปุ่มสั่งงานกลับเข้าทีม" — มีทาง trigger Claude Code session หรือ cloud routine จากภายนอกไหม (CLI, URL scheme, API)?
5. Google Calendar อ่านผ่านทางไหนเหมาะสุดสำหรับแอปส่วนตัวคนเดียว?

**ความยาก: L** (ทำเป็น phase: Deck = Card 1/3 ที่งอกฟีเจอร์ทีละแถบ ไม่ใช่สร้างใหม่จากศูนย์)

---

## คำแนะนำของ Minnie: เริ่มที่ไหน

**ลำดับที่เสนอ: Card 3 → Card 1 → Card 4 (skin) → Card 2 → Card 5**

เหตุผล: คอขวดจริงของทุกใบคือคำถามเดียวกัน — **"ดึงข้อมูล limit ของ Claude มาจากไหน"** (RQ ซ้ำใน Card 1, 2, 3) ระหว่างรอ Reese ตอบ เราเริ่ม Card 3 ได้ทันทีเพราะฝั่ง agent status ใช้ของที่มีอยู่แล้ว 100% ไม่ติด research → ได้ของใช้จริงเร็วสุด แล้วค่อยเสียบข้อมูล Claude เข้าไปเมื่อ Reese กลับมา ส่วน Card 4 ให้ Mind/Vera เริ่มออกแบบคู่ขนานได้เลย

**งานแรกของ Reese (สำคัญสุด, บล็อกทุกใบ):** RQ 1-2 ของ Card 1 + RQ 2 ของ Card 2 (แกะวิธีของ widget ต้นแบบ) — ตอบชุดนี้ชุดเดียว ปลดล็อก 4 ใน 5 ใบ

*หมายเหตุตาม FACT-CHECK RULE: idea cards ชุดนี้มี factual claims (ชื่อเครื่องมือ, ฟีเจอร์ macOS, API ต่างๆ) — ต้องผ่าน Reese fact-check ก่อนใช้ตัดสินใจลงมือ*
