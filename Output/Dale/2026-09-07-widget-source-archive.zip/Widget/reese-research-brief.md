# AGAPAE Widget — Research Brief (Reese)

วันที่: 19 ก.ค. 2026 | ผู้วิจัย: Reese (Research, Data & Fact-Check)
เครื่องเป้าหมาย: macOS (Darwin 24.3) | ผู้ใช้ stack: Vite + React (ไม่เขียน Swift)

ระดับความมั่นใจ: ✅ ตรวจแล้วจริงในเครื่องนี้ / 🌐 จากเว็บ (มี URL) / ⚠️ คาดเดา-ยังไม่ยืนยัน
กติกา: ไม่มี credential/token ใดๆ ในรายงานนี้

---

## 1. แหล่งข้อมูล Claude usage / limits

### 1.1 ข้อมูล token ต่อข้อความ — มีจริงใน transcript ✅

Claude Code เขียน transcript ทุก session ไว้ที่:

```
~/.claude/projects/<โฟลเดอร์ต่อ project>/<session-id>.jsonl
```

✅ ตรวจจริง: เครื่องนี้มี ~20 project dirs (เช่น `-Users-agapae-Documents-Work-PAE-Claude-AGAPAE-Agent`)
แต่ละบรรทัดคือ 1 message; บรรทัด `type: "assistant"` มี `message.usage` ครบ:

- `input_tokens`, `output_tokens`
- `cache_creation_input_tokens`, `cache_read_input_tokens`
- `service_tier`, `server_tool_use` และ `message.model` (เช่น `claude-opus-4-8`)
- บรรทัดยังมี `timestamp`, `sessionId`, `cwd`, `requestId`

**ใช้ทำอะไรได้:**
- **Context window %** ✅ คำนวณได้จาก usage ของ assistant message ล่าสุดของ session:
  `(input_tokens + cache_read + cache_creation) / ขนาด context window ของโมเดล`
- **Token count รายวัน/ราย session** ✅ รวมจากทุกไฟล์ (วิธีเดียวกับ ccusage)

### 1.2 % session limit / weekly limit — ไม่มีเก็บเป็นไฟล์ local ✅

✅ ตรวจจริง: grep หา `rate_limit / resetsAt / weekly / five_hour / utilization` ในไฟล์ .json
ใต้ `~/.claude/` (นอก projects/file-history) → **ไม่พบ** ไฟล์เก็บ % limit
✅ `~/.claude/.credentials.json` **ไม่มีบนเครื่องนี้** — macOS เก็บ credential ของ Claude Code
ไว้ใน **Keychain** (item ชื่อ "Claude Code-credentials" — ตรวจว่ามีอยู่จริง, ไม่ได้อ่านค่า)

### 1.3 % limit จริงมาจาก OAuth usage endpoint 🌐 (ความมั่นใจสูง)

Widget ชุมชนทั้งหลายได้ % session/weekly จาก:

```
GET https://api.anthropic.com/api/oauth/usage
Authorization: Bearer <OAuth token ของ Claude Code>
User-Agent: claude-code/<version>   ← จำเป็น ไม่ใส่จะโดน 429 ถาวร
```

ตอบกลับเป็น JSON: `five_hour` และ `seven_day` (แต่ละอันมี `utilization` 0-100 และ
`resets_at`) + limit แยกรายโมเดล (Sonnet/Opus) + extra usage — ข้อมูลชุดเดียวกับหน้า
Settings → Usage บน claude.ai

- 🌐 โครงสร้าง response + เงื่อนไข User-Agent + interval ปลอดภัย ~180 วินาที:
  https://github.com/anthropics/claude-code/issues/31021 และ
  https://github.com/anthropics/claude-code/issues/31637
- ✅ ตรวจจริง: curl endpoint นี้แบบไม่มี auth จากเครื่องนี้ → ได้ HTTP **429**
  (ตรงกับรายงานว่า bucket ไม่มี/ผิด header โดน rate-limit แรง) — ยืนยันว่า endpoint มีอยู่จริง
- ⚠️ เป็น endpoint ภายใน ไม่ใช่ API ที่ประกาศ official — อาจเปลี่ยนได้ (Anthropic มี issue
  ขอ API ทางการอยู่: https://github.com/anthropics/claude-code/issues/45392)

**บน macOS ต้องดึง token จาก Keychain** ⚠️ (วิธีมาตรฐาน ยังไม่ได้ทดลองรันจริง):
`security find-generic-password -s "Claude Code-credentials" -w` แล้ว parse JSON เอา
accessToken — ควรอ่านใหม่ทุกครั้งที่เจอ 401 เพราะ Claude Code refresh token ให้เอง

### 1.4 เครื่องมือ OSS ที่มีอยู่แล้ว 🌐

| เครื่องมือ | วิธี | ได้อะไร |
|---|---|---|
| **ccusage** (npm, `npx ccusage`) | parse JSONL ใน `~/.claude/projects/` ทั้งหมด offline | token count, cost ประมาณการ, 5-hour window แบบ**คำนวณเอง** — ไม่ใช่ % limit จริงจากเซิร์ฟเวอร์ |
| **claude-usage-widget** (projectvelox) | เรียก `/api/oauth/usage` ด้วย OAuth token, adaptive polling | % session/weekly/per-model **จริง** — Windows-first, macOS ต้อง build เอง |
| **usage-monitor-for-claude** (jens-duttke) | tray app Windows, endpoint เดียวกัน | % limits realtime |
| **claude-usage-widget** (bozdemir, pip) | cross-platform รวม macOS | session/weekly, forecast, themes |

Sources: https://ccusage.com , https://github.com/projectvelox/claude-usage-widget ,
https://github.com/jens-duttke/usage-monitor-for-claude ,
https://github.com/bozdemir/claude-usage-widget ,
https://github.com/niccolo-sabato/claude-usage-widget

### 1.5 widget ต้นแบบของชุมชนได้ % มาจากไหน

🌐 ยืนยันจาก README ของ projectvelox/claude-usage-widget (fetch จริง): ใช้
`https://api.anthropic.com/api/oauth/usage` + Bearer token จาก `~/.claude/.credentials.json`
และมี mascot/threshold สี ตรงกับที่ Kittanate เล่า
⚠️ ตัวที่ชุมชนไทยแชร์อาจเป็น repo นี้หรือ fork/ตัวใกล้เคียง (มีหลายตัวฟีเจอร์คล้ายกัน เช่น
ตัวที่มี mascot "Claw'd") — ระบุ repo แน่นอนไม่ได้ แต่**กลไกได้ % แบบเดียวกันทุกตัว**
คือ OAuth usage endpoint ความมั่นใจในกลไก: สูง

---

## 2. แหล่งข้อมูลงาน Agent ✅ (ตรวจจริงทั้งหมด)

### 2.1 worklog.json / status.json

`~/Documents/Work PAE/Claude/AGAPAE Agent/`

**worklog.json** — `{ updatedAt, entries[] }` (ปัจจุบัน 79 entries) แต่ละ entry:
`id, datetime, displayDate (ไทย พ.ศ.), displayTime, agent, agentName, agentImg,
pipeline, status, title, summary`

**status.json** — `{ updatedAt, agents[] }` (11 agents) แต่ละตัว:
`id, name, role, pipeline, img, persona, caps, what, status, task, report`

### 2.2 ดึงผ่าน GitHub Pages ✅ ใช้ได้

`https://hellopae.github.io/AGAPAEagent/worklog.json`
- ✅ curl จริง: HTTP 200, `content-type: application/json`
- ✅ `access-control-allow-origin: *` → fetch จากเว็บ/widget ได้ทุก origin ไม่ติด CORS
- ⚠️ ข้อจำกัด: `cache-control: max-age=600` → CDN อาจ stale ได้ถึง ~10 นาที
  (แก้ได้ด้วย query string cache-buster `?t=<timestamp>`)

### 2.3 Firestore realtime ✅

✅ ตรวจ `scripts/hook-status.mjs`: hook เขียน 2 ที่ผ่าน Firestore REST —
doc `agents/<agentId>` (status) และ arrayUnion ลง doc `agents/worklog`
(คอมเมนต์ในโค้ดระบุว่า dashboard ฟัง doc นี้แบบ realtime อยู่แล้ว)
→ widget ใช้ Firebase JS SDK `onSnapshot('agents/worklog')` ได้ทันที ไม่ต้อง poll
(stack Firebase มีอยู่แล้วในทีม)

---

## 3. รูปแบบ app บน macOS — เปรียบเทียบ

| วิธี | ภาษา/เครื่องมือ | ความยาก | Bundle/RAM | เหมาะกับ |
|---|---|---|---|---|
| **xbar / SwiftBar** (menu bar รันสคริปต์) | สคริปต์อะไรก็ได้ (Node/Bash) | ต่ำมาก | เบามาก | MVP โชว์ % ใน menu bar ภายในวันเดียว — แต่ UI เป็น text/menu ทำ mascot/กราฟสวยไม่ได้ |
| **Hammerspoon** | Lua | ต่ำ-กลาง | เบา | คนใช้ Hammerspoon อยู่แล้ว — ขัด stack (Lua) |
| **Tauri v2** tray + floating window | **React frontend** + Rust (boilerplate น้อย) | กลาง (ต้องลง Rust toolchain) | ~5-10 MB, RAM ~30-40 MB | ตัวเต็มแบบต้นแบบ: tray + always-on-top + mascot ปรับสี — ใกล้ stack สุดในกลุ่ม native |
| **Electron** tray + floating window | JS/React ล้วน | ต่ำ-กลาง (คุ้นสุด) | ~85-120+ MB, RAM หลักร้อย MB | ทำเร็วถ้าไม่แคร์ขนาด/แบต |
| **WidgetKit** (Notification Center/desktop widget) | **Swift/SwiftUI + Xcode เท่านั้น** | สูง | — | **ขัด stack ตรงๆ** และ widget เป็น timeline snapshot ไม่ realtime — ไม่แนะนำ |
| **เว็บ/PWA แท็บค้าง** | Vite+React เดิม | ต่ำสุด | — | โชว์งานทีม (Firestore/Pages) ได้เต็มที่ แต่**อ่านไฟล์ local/Keychain ไม่ได้** (browser sandbox) → ไม่ได้ % limit ยกเว้นมี local helper; ไม่มี always-on-top |

🌐 ขนาด/RAM Tauri vs Electron: https://www.dolthub.com/blog/2025-11-13-electron-vs-tauri/ ,
https://betterprogramming.pub/tauri-vs-electron-for-tray-apps-ed15974f35ce
⚠️ ตัวเลข bundle เป็นช่วงทั่วไปจากหลายแหล่ง ไม่ใช่ benchmark ของเราเอง

**จุดสำคัญ:** always-on-top ทั้ง Tauri (`alwaysOnTop: true` ใน window config) และ
Electron (`win.setAlwaysOnTop(true)`) เป็น option เดียว ไม่ยาก 🌐 (docs ทางการทั้งคู่)

---

## 4. การอัปเดตอัตโนมัติ

| แหล่ง | วิธี | interval แนะนำ | ต้นทุนแบต |
|---|---|---|---|
| OAuth usage endpoint | poll (ต้องมี User-Agent ถูก) | **≥ 180 วิ** (ต่ำกว่านี้เสี่ยง 429) 🌐 issue #31021 | ต่ำ (HTTP call เล็ก) |
| JSONL transcripts | fs watch ที่ dir ของ project ปัจจุบัน (debounce) หรือ poll 30-60 วิ | 30-60 วิ | ต่ำ ถ้า tail เฉพาะไฟล์ล่าสุด ไม่ re-parse ทั้งหมด |
| Firestore `agents/worklog` | `onSnapshot` realtime | — (push เอง) | ต่ำมาก |
| Pages worklog.json | poll fetch | 5-10 นาที (ตาม CDN cache) | ต่ำ |

แบต/ทรัพยากรตามแนว app: xbar (สคริปต์รันเป็นรอบ) < Tauri (WKWebView) << Electron
(Chromium ค้างตลอด) — ⚠️ ลำดับทั่วไป ยังไม่ได้วัดจริง

---

## คำแนะนำ Architecture (2 แนว)

### แนว A — แนะนำหลัก: Tauri v2 tray + floating widget (React)
- Frontend: Vite + React (ตรง stack) — mascot, สี theme, bar % ทำเต็มที่
- Rust side (โค้ดสั้น ส่วนใหญ่เป็น config): อ่าน token จาก Keychain, เรียก
  `/api/oauth/usage` ทุก 3 นาที, tail JSONL เอา context %, ส่งเข้า webview ผ่าน event
- งานทีม: Firebase JS SDK `onSnapshot('agents/worklog')` ใน webview โดยตรง
- ได้ครบ: tray icon + floating always-on-top แบบต้นแบบ, bundle เล็ก, กินแบตน้อย
- ความเสี่ยง: ต้องลง Rust toolchain + เรียน Tauri เบื้องต้น (มี template tray พร้อมใช้)

### แนว B — MVP เร็วสุด (ทำก่อนได้ใน 1 วัน): SwiftBar/xbar plugin เป็น Node script
- สคริปต์เดียว: ดึง Keychain token → เรียก usage endpoint → แสดง `S:42% W:18%`
  บน menu bar + dropdown รายละเอียด + parse JSONL เพิ่ม context %
- งานทีม: fetch Pages worklog.json แสดง entry ล่าสุดใน dropdown
- ข้อจำกัด: UI เป็น text ไม่มี mascot — ใช้เป็น stepping stone ไปแนว A ได้
  (logic ดึงข้อมูลเขียนเป็น Node module เดียว reuse ต่อใน Tauri ได้เลย)

**ไม่แนะนำ:** WidgetKit (ต้อง Swift ขัด stack + ไม่ realtime), Electron (ทำได้แต่
bundle/RAM หนักเกินงาน widget)

---

## ความเสี่ยงรวมที่ต้องรับทราบ
1. `/api/oauth/usage` เป็น endpoint ภายใน อาจเปลี่ยน schema/นโยบายได้ทุกเมื่อ ⚠️
2. ห้าม hardcode token — อ่านจาก Keychain สดทุกครั้ง และห้าม log ค่า token
3. Rate limit: เคารพ interval ≥180 วิ + ใส่ User-Agent `claude-code/<version>` เสมอ
4. โครงสร้าง JSONL ไม่มีสัญญา official — pin logic ไว้กับ field ที่ ccusage ใช้ (เสถียรมานาน)
